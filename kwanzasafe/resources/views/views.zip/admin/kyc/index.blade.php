<x-app-layout>

<style>
body { background:#f8fafc; }
.kyc-topbar { background:#0f172a; color:white; padding:0.875rem 1.5rem; display:flex; align-items:center; justify-content:space-between; position:sticky; top:0; z-index:50; box-shadow:0 2px 8px rgba(0,0,0,0.1); }
.kyc-topbar__back { color:#94a3b8; text-decoration:none; font-size:0.8rem; font-weight:600; display:flex; align-items:center; gap:0.5rem; transition:color 0.15s; }
.kyc-topbar__back:hover { color:white; }
.kyc-topbar__title { font-family:'Syne',sans-serif; font-weight:800; font-size:0.95rem; }
.kyc-topbar__logo { height:28px; width:auto; filter:brightness(0) invert(1); }
.kyc-topbar__badge { background:#f59e0b; color:white; font-size:0.65rem; font-weight:800; padding:3px 10px; border-radius:20px; letter-spacing:0.08em; text-transform:uppercase; }

.kyc-container { max-width:1200px; margin:0 auto; padding:1.5rem; }
.kyc-flash { padding:0.875rem 1.125rem; border-radius:12px; font-size:0.85rem; font-weight:500; display:flex; align-items:center; gap:0.625rem; margin-bottom:1rem; }
.kyc-flash.success { background:#ecfdf5; border:1px solid #a7f3d0; color:#065f46; }
.kyc-flash.error { background:#fee2e2; border:1px solid #fca5a5; color:#991b1b; }

.kyc-section { margin-bottom:2.5rem; }
.kyc-section__head { display:flex; align-items:center; gap:0.75rem; margin-bottom:1rem; }
.kyc-section__icon { width:40px; height:40px; border-radius:12px; display:flex; align-items:center; justify-content:center; flex-shrink:0; }
.kyc-section__icon.warn { background:#fef3c7; color:#d97706; }
.kyc-section__icon.ok { background:#d1fae5; color:#065f46; }
.kyc-section__title { font-family:'Syne',sans-serif; font-weight:800; font-size:1.125rem; letter-spacing:-0.01em; }
.kyc-section__sub { font-size:0.75rem; color:#64748b; margin-top:-2px; }

/* Pending Cards */
.kyc-pending-card { background:white; border:1px solid #fde68a; border-radius:16px; overflow:hidden; margin-bottom:0.875rem; transition:all 0.2s; box-shadow:0 1px 3px rgba(0,0,0,0.03); }
.kyc-pending-card:hover { box-shadow:0 8px 24px rgba(245,158,11,0.15); transform:translateY(-1px); }
.kyc-pending-card__body { display:flex; align-items:center; gap:1rem; padding:1.125rem 1.25rem; }
.kyc-pending-card__avatar { width:48px; height:48px; border-radius:50%; background:#ecfdf5; border:2px solid #a7f3d0; display:flex; align-items:center; justify-content:center; font-family:'Syne',sans-serif; font-weight:800; color:#064e3b; font-size:1rem; overflow:hidden; flex-shrink:0; }
.kyc-pending-card__info { flex:1; min-width:0; }
.kyc-pending-card__name { font-family:'Syne',sans-serif; font-size:1rem; font-weight:800; color:#0f172a; }
.kyc-pending-card__meta { font-size:0.75rem; color:#64748b; margin-top:2px; display:flex; gap:0.375rem; align-items:center; flex-wrap:wrap; }
.kyc-pending-card__meta strong { color:#0f172a; font-weight:700; }
.kyc-pending-card__time { font-size:0.7rem; color:#d97706; font-weight:700; margin-top:4px; }
.kyc-mini-tag { display:inline-block; font-size:0.58rem; font-weight:800; padding:2px 7px; border-radius:20px; text-transform:uppercase; letter-spacing:0.08em; }
.kyc-mini-tag.ok { background:#ecfdf5; color:#065f46; }
.kyc-mini-tag.info { background:#dbeafe; color:#1e40af; }
.kyc-mini-tag.purple { background:#ede9fe; color:#6d28d9; }

.kyc-pending-card__btn { background:#0f172a; color:white; padding:0.5rem 1rem; border-radius:10px; font-family:'Syne',sans-serif; font-size:0.7rem; font-weight:800; letter-spacing:0.05em; text-transform:uppercase; text-decoration:none; transition:all 0.15s; display:inline-flex; align-items:center; gap:0.375rem; flex-shrink:0; }
.kyc-pending-card__btn:hover { background:#334155; transform:translateX(2px); }

.kyc-pending-card__progress { padding:0 1.25rem 0.875rem; }
.kyc-progress-bar { display:flex; gap:3px; margin-bottom:4px; }
.kyc-progress-cell { flex:1; height:5px; border-radius:3px; background:#e2e8f0; }
.kyc-progress-cell.done { background:#10b981; }
.kyc-progress-label { font-size:0.65rem; color:#94a3b8; font-weight:600; }

/* Empty */
.kyc-empty { background:white; border-radius:16px; border:1px dashed #cbd5e1; padding:3rem 1.5rem; text-align:center; }
.kyc-empty__icon { font-size:3rem; margin-bottom:0.75rem; }
.kyc-empty__title { font-family:'Syne',sans-serif; font-size:1rem; font-weight:800; margin-bottom:0.25rem; }
.kyc-empty__sub { font-size:0.8rem; color:#64748b; }

/* Approved Table */
.kyc-table-wrap { background:white; border-radius:16px; border:1px solid #e2e8f0; overflow:hidden; box-shadow:0 1px 3px rgba(0,0,0,0.03); }
.kyc-table { width:100%; font-size:0.875rem; border-collapse:collapse; }
.kyc-table thead { background:#f8fafc; }
.kyc-table th { text-align:left; padding:0.75rem 1rem; font-size:0.6rem; font-weight:800; color:#64748b; text-transform:uppercase; letter-spacing:0.1em; border-bottom:1px solid #e2e8f0; }
.kyc-table tbody tr { border-bottom:1px solid #f1f5f9; transition:background 0.15s; }
.kyc-table tbody tr:last-child { border-bottom:none; }
.kyc-table tbody tr:hover { background:#f8fafc; }
.kyc-table td { padding:0.75rem 1rem; vertical-align:middle; }
.kyc-user-cell { display:flex; align-items:center; gap:0.625rem; }
.kyc-user-cell__avatar { width:32px; height:32px; border-radius:50%; background:#d1fae5; color:#064e3b; display:flex; align-items:center; justify-content:center; font-family:'Syne',sans-serif; font-weight:800; font-size:0.75rem; overflow:hidden; flex-shrink:0; }
.kyc-user-cell__name { font-weight:600; color:#0f172a; font-size:0.825rem; }
.kyc-user-cell__email { font-size:0.7rem; color:#94a3b8; }
.kyc-bi-tag { font-family:'JetBrains Mono',monospace; font-size:0.7rem; background:#f1f5f9; padding:3px 8px; border-radius:6px; color:#475569; font-weight:600; }
.kyc-table__link { font-size:0.7rem; font-weight:800; color:#065f46; text-decoration:none; transition:color 0.15s; }
.kyc-table__link:hover { color:#064e3b; }

@media(max-width:768px) {
    .kyc-table th:nth-child(2), .kyc-table td:nth-child(2),
    .kyc-table th:nth-child(3), .kyc-table td:nth-child(3) { display:none; }
    .kyc-pending-card__body { flex-wrap:wrap; }
    .kyc-pending-card__btn { width:100%; justify-content:center; margin-top:0.5rem; }
}
</style>

<div class="kyc-topbar">
    <a href="{{ route('admin.dashboard') }}" class="kyc-topbar__back">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
        Painel
    </a>
    <div style="display:flex;align-items:center;gap:0.625rem;">
        <img src="{{ asset('assets/images/logos/logo1.png') }}" class="kyc-topbar__logo" alt="KwanzaSafe" onerror="this.style.display='none'">
        <span class="kyc-topbar__title">Verificação KYC</span>
    </div>
    @if($pendingUsers->count() > 0)
        <span class="kyc-topbar__badge">{{ $pendingUsers->count() }} pendente{{ $pendingUsers->count() > 1 ? 's' : '' }}</span>
    @else
        <span style="width:80px;"></span>
    @endif
</div>

<div class="kyc-container">

    @if(session('success'))
        <div class="kyc-flash success">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
            {{ session('success') }}
        </div>
    @endif
    @if(session('error'))
        <div class="kyc-flash error">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>
            {{ session('error') }}
        </div>
    @endif

    {{-- ====== PENDENTES ====== --}}
    <div class="kyc-section">
        <div class="kyc-section__head">
            <div class="kyc-section__icon warn">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
            </div>
            <div>
                <div class="kyc-section__title font-display">A Aguardar Revisão</div>
                <div class="kyc-section__sub">Documentos submetidos que precisam de aprovação do admin</div>
            </div>
        </div>

        @if($pendingUsers->isEmpty())
            <div class="kyc-empty">
                <div class="kyc-empty__icon">✅</div>
                <div class="kyc-empty__title font-display">Tudo em Dia!</div>
                <div class="kyc-empty__sub">Nenhum documento KYC pendente neste momento.</div>
            </div>
        @else
            @foreach($pendingUsers as $u)
                @php
                    $steps = [
                        $u->data_verified,
                        (bool) $u->phone_verified_at,
                        (bool) $u->identity_document_path,
                        (bool) $u->profile_photo_path,
                    ];
                    $done = count(array_filter($steps));
                @endphp
                <div class="kyc-pending-card">
                    <div class="kyc-pending-card__body">
                        <div class="kyc-pending-card__avatar">
                            @if($u->profile_photo_path)
                                <img src="{{ asset('storage/'.$u->profile_photo_path) }}" 
                                style="width:100%;height:100%;object-fit:cover;">
                            @else
                                {{ strtoupper(substr($u->full_name ?? $u->email, 0, 1)) }}
                            @endif
                        </div>
                        <div class="kyc-pending-card__info">
                            <div class="kyc-pending-card__name">{{ $u->full_name ?? 'Sem nome' }}</div>
                            <div class="kyc-pending-card__meta">
                                {{ $u->email }}
                                @if($u->bi_number) • BI: <strong>{{ $u->bi_number }}</strong>@endif
                                @if($u->province) • {{ $u->province }}@endif
                            </div>
                            <div style="display:flex;gap:4px;margin-top:6px;flex-wrap:wrap;">
                                @if($u->data_verified)<span class="kyc-mini-tag ok">Dados ✓</span>@endif
                                @if($u->phone_verified_at)<span class="kyc-mini-tag info">Tel ✓</span>@endif
                                @if($u->profile_photo_path)<span class="kyc-mini-tag purple">Selfie ✓</span>@endif
                            </div>
                            <div class="kyc-pending-card__time">
                                ⏳ Documento enviado {{ $u->updated_at->diffForHumans() }}
                            </div>
                        </div>
                        <a href="{{ route('admin.kyc.show', $u->id) }}" class="kyc-pending-card__btn">
                            Rever
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/></svg>
                        </a>
                    </div>

                    <div class="kyc-pending-card__progress">
                        <div class="kyc-progress-bar">
                            @foreach($steps as $s)
                                <div class="kyc-progress-cell {{ $s ? 'done' : '' }}"></div>
                            @endforeach
                        </div>
                        <div class="kyc-progress-label">{{ $done }}/4 passos concluídos pelo cliente</div>
                    </div>
                </div>
            @endforeach
        @endif
    </div>

    {{-- ====== APROVADOS ====== --}}
    <div class="kyc-section">
        <div class="kyc-section__head">
            <div class="kyc-section__icon ok">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
            </div>
            <div>
                <div class="kyc-section__title font-display">Aprovados Recentes</div>
                <div class="kyc-section__sub">Últimos 20 utilizadores com identidade verificada</div>
            </div>
        </div>

        @if($approvedUsers->isEmpty())
            <div class="kyc-empty">
                <div class="kyc-empty__icon">🪪</div>
                <div class="kyc-empty__sub">Ainda não há utilizadores aprovados.</div>
            </div>
        @else
            <div class="kyc-table-wrap">
                <table class="kyc-table">
                    <thead>
                        <tr>
                            <th>Utilizador</th>
                            <th>BI</th>
                            <th>Aprovado em</th>
                            <th style="text-align:right;">Ação</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($approvedUsers as $u)
                            <tr>
                                <td>
                                    <div class="kyc-user-cell">
                                        <div class="kyc-user-cell__avatar">
                                            @if($u->profile_photo_path)
                                                <img src="{{ asset('storage/'.$u->profile_photo_path) }}" style="width:100%;height:100%;object-fit:cover;">
                                            @else
                                                {{ strtoupper(substr($u->full_name ?? $u->email, 0, 1)) }}
                                            @endif
                                        </div>
                                        <div>
                                            <div class="kyc-user-cell__name">{{ $u->full_name ?? 'Sem nome' }}</div>
                                            <div class="kyc-user-cell__email">{{ $u->email }}</div>
                                        </div>
                                    </div>
                                </td>
                                <td><span class="kyc-bi-tag">{{ $u->bi_number ?? '—' }}</span></td>
                                <td style="font-size:0.75rem;color:#64748b;">
                                    {{ $u->identity_verified_at?->format('d/m/Y H:i') ?? '—' }}
                                </td>
                                <td style="text-align:right;">
                                    <a href="{{ route('admin.kyc.show', $u->id) }}" class="kyc-table__link">Ver →</a>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        @endif
    </div>

</div>

</x-app-layout>
