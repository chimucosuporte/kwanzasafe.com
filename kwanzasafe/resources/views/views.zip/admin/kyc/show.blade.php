<x-app-layout>

<style>
body { background:#f8fafc; }
.kycs-topbar { background:#0f172a; color:white; padding:0.875rem 1.5rem; display:flex; align-items:center; justify-content:space-between; position:sticky; top:0; z-index:50; box-shadow:0 2px 8px rgba(0,0,0,0.1); }
.kycs-topbar__back { color:#94a3b8; text-decoration:none; font-size:0.8rem; font-weight:600; display:flex; align-items:center; gap:0.5rem; transition:color 0.15s; }
.kycs-topbar__back:hover { color:white; }
.kycs-topbar__title { font-family:'Syne',sans-serif; font-weight:800; font-size:0.95rem; }
.kycs-topbar__logo { height:28px; filter:brightness(0) invert(1); }

.kycs-container { max-width:1400px; margin:0 auto; padding:1.5rem; }

.kycs-flash { padding:0.875rem 1.125rem; border-radius:12px; font-size:0.85rem; font-weight:500; margin-bottom:1rem; }
.kycs-flash.success { background:#ecfdf5; border:1px solid #a7f3d0; color:#065f46; }
.kycs-flash.error { background:#fee2e2; border:1px solid #fca5a5; color:#991b1b; }

.kycs-grid { display:grid; grid-template-columns:1fr 2fr; gap:1.25rem; }
@media(max-width:1024px) { .kycs-grid { grid-template-columns:1fr; } }

.kycs-card { background:white; border-radius:16px; border:1px solid #e2e8f0; overflow:hidden; margin-bottom:1rem; box-shadow:0 1px 3px rgba(0,0,0,0.03); }
.kycs-card__head { padding:0.875rem 1.125rem; border-bottom:1px solid #f1f5f9; display:flex; align-items:center; justify-content:space-between; background:#fcfcfd; }
.kycs-card__title { font-family:'Syne',sans-serif; font-size:0.7rem; font-weight:800; text-transform:uppercase; letter-spacing:0.08em; color:#64748b; }
.kycs-card__body { padding:1.25rem; }

/* Status Hero */
.kycs-hero { padding:1.5rem 1.125rem; text-align:center; }
.kycs-hero__avatar { width:88px; height:88px; border-radius:50%; background:#d1fae5; border:3px solid #a7f3d0; overflow:hidden; display:flex; align-items:center; justify-content:center; margin:0 auto 0.875rem; font-family:'Syne',sans-serif; font-size:2rem; font-weight:800; color:#065f46; }
.kycs-hero__name { font-family:'Syne',sans-serif; font-size:1.1rem; font-weight:800; color:#0f172a; letter-spacing:-0.01em; }
.kycs-hero__email { font-size:0.75rem; color:#94a3b8; margin-top:2px; }
.kycs-status-pill { display:inline-flex; align-items:center; gap:0.375rem; font-size:0.65rem; font-weight:800; padding:4px 10px; border-radius:20px; text-transform:uppercase; letter-spacing:0.08em; margin-top:0.75rem; }
.kycs-status-pill.ok { background:#d1fae5; color:#065f46; }
.kycs-status-pill.warn { background:#fef3c7; color:#92400e; }

/* Data Rows */
.kycs-datarow { padding:0.75rem 1.125rem; display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid #f1f5f9; gap:0.75rem; font-size:0.8rem; }
.kycs-datarow:last-child { border-bottom:none; }
.kycs-datarow__label { color:#94a3b8; font-weight:500; flex-shrink:0; }
.kycs-datarow__value { color:#0f172a; font-weight:700; text-align:right; }
.kycs-datarow__bi { font-family:'JetBrains Mono',monospace; font-size:0.75rem; background:#f1f5f9; padding:2px 7px; border-radius:6px; color:#475569; }

/* Checklist */
.kycs-checklist { padding:1rem; display:flex; flex-direction:column; gap:0.5rem; }
.kycs-check { display:flex; align-items:center; gap:0.625rem; font-size:0.825rem; }
.kycs-check__circle { width:22px; height:22px; border-radius:50%; display:flex; align-items:center; justify-content:center; flex-shrink:0; }
.kycs-check__circle.done { background:#10b981; color:white; }
.kycs-check__circle.undone { background:#e2e8f0; color:#94a3b8; font-family:'Syne',sans-serif; font-weight:800; font-size:0.65rem; }
.kycs-check__label.done { color:#065f46; font-weight:600; }
.kycs-check__label.undone { color:#94a3b8; }

/* Document Viewer */
.kycs-doc-wrap { background:#f8fafc; border:2px solid #e2e8f0; border-radius:12px; padding:1rem; min-height:300px; display:flex; align-items:center; justify-content:center; position:relative; }
.kycs-doc-wrap img { max-width:100%; max-height:500px; border-radius:8px; cursor:zoom-in; box-shadow:0 4px 16px rgba(0,0,0,0.08); }
.kycs-doc-open-link { position:absolute; bottom:12px; right:12px; background:rgba(15,23,42,0.9); color:white; font-size:0.65rem; font-weight:700; padding:6px 12px; border-radius:8px; text-decoration:none; display:inline-flex; align-items:center; gap:0.375rem; backdrop-filter:blur(4px); }
.kycs-doc-pdf { text-align:center; padding:2rem; }
.kycs-doc-pdf a { display:inline-flex; align-items:center; gap:0.5rem; background:#0f172a; color:white; padding:0.75rem 1.25rem; border-radius:10px; text-decoration:none; font-family:'Syne',sans-serif; font-weight:800; font-size:0.8rem; text-transform:uppercase; letter-spacing:0.05em; }
.kycs-doc-pdf a:hover { background:#334155; }

.kycs-doc-empty { text-align:center; color:#94a3b8; padding:2rem; }

/* Selfie side-by-side */
.kycs-selfie-row { display:grid; grid-template-columns:120px 1fr; gap:1.25rem; align-items:center; padding:1rem; }
@media(max-width:600px) { .kycs-selfie-row { grid-template-columns:1fr; text-align:center; } }
.kycs-selfie-img { width:120px; height:120px; border-radius:16px; object-fit:cover; border:3px solid #d1fae5; box-shadow:0 4px 16px rgba(0,0,0,0.08); cursor:zoom-in; }
.kycs-selfie-info { font-size:0.825rem; color:#475569; line-height:1.6; }
.kycs-selfie-info strong { color:#0f172a; }
.kycs-selfie-info ul { list-style:none; padding:0; margin:0.5rem 0 0; }
.kycs-selfie-info ul li { font-size:0.7rem; color:#94a3b8; display:flex; align-items:center; gap:0.5rem; margin-bottom:3px; }
.kycs-selfie-info ul li::before { content:''; width:5px; height:5px; background:#cbd5e1; border-radius:50%; }

/* Decision Panel */
.kycs-decision { background:linear-gradient(135deg, #0f172a 0%, #020617 100%); border-radius:20px; padding:1.75rem; color:white; box-shadow:0 20px 60px rgba(0,0,0,0.15); margin-top:1.25rem; }
.kycs-decision__title { font-family:'Syne',sans-serif; font-size:1.125rem; font-weight:800; margin-bottom:0.375rem; letter-spacing:-0.01em; }
.kycs-decision__sub { font-size:0.8rem; color:rgba(255,255,255,0.6); margin-bottom:1.25rem; line-height:1.5; }
.kycs-decision__actions { display:grid; grid-template-columns:1fr 1fr; gap:1rem; }
@media(max-width:600px) { .kycs-decision__actions { grid-template-columns:1fr; } }

.kycs-btn-approve { background:#10b981; color:white; padding:0.875rem 1.125rem; border-radius:12px; font-family:'Syne',sans-serif; font-weight:800; font-size:0.8rem; text-transform:uppercase; letter-spacing:0.05em; border:none; cursor:pointer; display:flex; align-items:center; justify-content:center; gap:0.5rem; transition:all 0.18s; box-shadow:0 6px 16px rgba(16,185,129,0.25); width:100%; }
.kycs-btn-approve:hover { background:#059669; transform:translateY(-1px); }

.kycs-reject-box { display:flex; flex-direction:column; gap:0.5rem; }
.kycs-reject-select { width:100%; background:rgba(255,255,255,0.1); border:1px solid rgba(255,255,255,0.2); color:white; padding:0.625rem 0.875rem; border-radius:10px; font-size:0.8rem; outline:none; }
.kycs-reject-select option { background:#0f172a; color:white; }
.kycs-reject-custom { width:100%; background:rgba(255,255,255,0.1); border:1px solid rgba(255,255,255,0.2); color:white; padding:0.625rem 0.875rem; border-radius:10px; font-size:0.8rem; outline:none; }
.kycs-reject-custom::placeholder { color:rgba(255,255,255,0.4); }
.kycs-btn-reject { background:#dc2626; color:white; padding:0.75rem 1rem; border-radius:10px; font-family:'Syne',sans-serif; font-weight:800; font-size:0.75rem; text-transform:uppercase; letter-spacing:0.05em; border:none; cursor:pointer; display:flex; align-items:center; justify-content:center; gap:0.5rem; transition:all 0.18s; }
.kycs-btn-reject:hover { background:#b91c1c; }

/* Approved Summary */
.kycs-approved-card { background:linear-gradient(135deg,#ecfdf5,#d1fae5); border:2px solid #a7f3d0; border-radius:16px; padding:1.25rem; margin-top:1.25rem; display:flex; align-items:center; gap:1rem; }
.kycs-approved-card__icon { width:48px; height:48px; background:#10b981; border-radius:12px; display:flex; align-items:center; justify-content:center; flex-shrink:0; }
.kycs-approved-card__title { font-family:'Syne',sans-serif; font-size:1rem; font-weight:800; color:#064e3b; }
.kycs-approved-card__sub { font-size:0.75rem; color:#065f46; margin-top:2px; }

.kycs-warning-empty { background:#fef3c7; border:2px solid #fde68a; border-radius:16px; padding:1.125rem 1.25rem; color:#78350f; font-size:0.85rem; font-weight:500; margin-top:1.25rem; line-height:1.5; }

/* Tag styles */
.kycs-tag { display:inline-block; font-size:0.58rem; font-weight:800; padding:3px 8px; border-radius:20px; text-transform:uppercase; letter-spacing:0.08em; }
.kycs-tag.ok { background:#ecfdf5; color:#065f46; }
.kycs-tag.blue { background:#dbeafe; color:#1e40af; }
.kycs-tag.purple { background:#ede9fe; color:#6d28d9; }
.kycs-tag.red { background:#fee2e2; color:#991b1b; }
</style>

<div class="kycs-topbar">
    <a href="{{ route('admin.kyc.index') }}" class="kycs-topbar__back">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
        Lista KYC
    </a>
    <div style="display:flex;align-items:center;gap:0.625rem;">
        <img src="{{ asset('assets/images/logos/logo1.png') }}" class="kycs-topbar__logo" alt="KwanzaSafe" onerror="this.style.display='none'">
        <span class="kycs-topbar__title">Revisão KYC</span>
    </div>
    <div style="font-size:0.65rem;color:#94a3b8;font-family:'JetBrains Mono',monospace;">ID #{{ $kycUser->id }}</div>
</div>

<div class="kycs-container">

    @if(session('error'))
        <div class="kycs-flash error">⚠️ {{ session('error') }}</div>
    @endif

    <div class="kycs-grid">

        {{-- ============ COLUNA ESQUERDA: PERFIL ============ --}}
        <div>
            {{-- Hero --}}
            <div class="kycs-card">
                <div class="kycs-hero">
                    <div class="kycs-hero__avatar">
                        @if($kycUser->profile_photo_path)
                            <img src="{{ asset('storage/'.$kycUser->profile_photo_path) }}" style="width:100%;height:100%;object-fit:cover;">
                        @else
                            {{ strtoupper(substr($kycUser->full_name ?? $kycUser->email, 0, 1)) }}
                        @endif
                    </div>
                    <div class="kycs-hero__name font-display">{{ $kycUser->full_name ?? 'Sem nome' }}</div>
                    <div class="kycs-hero__email">{{ $kycUser->email }}</div>
                    @if($kycUser->identity_verified_at)
                        <div class="kycs-status-pill ok">
                            ✓ Aprovado {{ $kycUser->identity_verified_at->format('d/m/Y') }}
                        </div>
                    @else
                        <div class="kycs-status-pill warn">
                            ⏳ Aguarda Aprovação
                        </div>
                    @endif
                </div>
            </div>

            {{-- Dados Pessoais --}}
            <div class="kycs-card">
                <div class="kycs-card__head">
                    <div class="kycs-card__title">Dados Pessoais</div>
                </div>
                <div style="padding:0;">
                    <div class="kycs-datarow">
                        <span class="kycs-datarow__label">Nome</span>
                        <span class="kycs-datarow__value">{{ $kycUser->full_name ?? '—' }}</span>
                    </div>
                    <div class="kycs-datarow">
                        <span class="kycs-datarow__label">Nascimento</span>
                        <span class="kycs-datarow__value">{{ optional($kycUser->birth_date)->format('d/m/Y') ?? '—' }}</span>
                    </div>
                    <div class="kycs-datarow">
                        <span class="kycs-datarow__label">Género</span>
                        <span class="kycs-datarow__value">
                            {{ $kycUser->gender === 'M' ? 'Masculino' : ($kycUser->gender === 'F' ? 'Feminino' : '—') }}
                        </span>
                    </div>
                    <div class="kycs-datarow">
                        <span class="kycs-datarow__label">Número BI</span>
                        <span class="kycs-datarow__bi">{{ $kycUser->bi_number ?? '—' }}</span>
                    </div>
                    <div class="kycs-datarow">
                        <span class="kycs-datarow__label">Validade BI</span>
                        <span class="kycs-datarow__value">{{ optional($kycUser->bi_expiry)->format('d/m/Y') ?? '—' }}</span>
                    </div>
                    <div class="kycs-datarow">
                        <span class="kycs-datarow__label">Província</span>
                        <span class="kycs-datarow__value">{{ $kycUser->province ?? '—' }}</span>
                    </div>
                    <div class="kycs-datarow">
                        <span class="kycs-datarow__label">Município</span>
                        <span class="kycs-datarow__value">{{ $kycUser->municipality ?? '—' }}</span>
                    </div>
                    <div class="kycs-datarow">
                        <span class="kycs-datarow__label">Endereço</span>
                        <span class="kycs-datarow__value" style="font-size:0.75rem;">{{ Str::limit($kycUser->address, 30) ?? '—' }}</span>
                    </div>
                    <div class="kycs-datarow">
                        <span class="kycs-datarow__label">Telefone</span>
                        <span class="kycs-datarow__value">{{ $kycUser->phone_number ?? '—' }}</span>
                    </div>
                    <div class="kycs-datarow">
                        <span class="kycs-datarow__label">Membro desde</span>
                        <span class="kycs-datarow__value">{{ $kycUser->created_at->format('d/m/Y') }}</span>
                    </div>
                    <div class="kycs-datarow">
                        <span class="kycs-datarow__label">Transações</span>
                        <span class="kycs-datarow__value">{{ $kycUser->transactions()->count() }}</span>
                    </div>
                </div>
            </div>

            {{-- Checklist KYC --}}
            <div class="kycs-card">
                <div class="kycs-card__head">
                    <div class="kycs-card__title">Checklist KYC</div>
                </div>
                @php
                    $checks = [
                        ['label' => 'Dados Pessoais',   'done' => (bool) $kycUser->data_verified],
                        ['label' => 'Telefone',         'done' => (bool) $kycUser->phone_verified_at],
                        ['label' => 'Documento BI',     'done' => (bool) $kycUser->identity_document_path],
                        ['label' => 'Selfie',           'done' => (bool) $kycUser->profile_photo_path],
                        ['label' => 'Aprovação Admin',  'done' => (bool) $kycUser->identity_verified_at],
                    ];
                @endphp
                <div class="kycs-checklist">
                    @foreach($checks as $i => $c)
                        <div class="kycs-check">
                            <div class="kycs-check__circle {{ $c['done'] ? 'done' : 'undone' }}">
                                @if($c['done'])
                                    <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>
                                @else
                                    {{ $i+1 }}
                                @endif
                            </div>
                            <span class="kycs-check__label {{ $c['done'] ? 'done' : 'undone' }}">{{ $c['label'] }}</span>
                        </div>
                    @endforeach
                </div>
            </div>

            {{-- Audit link --}}
            <a href="{{ route('admin.audit.user', $kycUser->id) }}" style="display:flex;align-items:center;justify-content:center;gap:0.5rem;background:#1e293b;color:white;padding:0.75rem;border-radius:12px;text-decoration:none;font-family:'Syne',sans-serif;font-weight:800;font-size:0.75rem;text-transform:uppercase;letter-spacing:0.05em;">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
                Ver Histórico Audit Trail
            </a>
        </div>

        {{-- ============ COLUNA DIREITA: DOCUMENTOS E AÇÕES ============ --}}
        <div>

            {{-- DOCUMENTO --}}
            <div class="kycs-card">
                <div class="kycs-card__head">
                    <div class="kycs-card__title">🪪 Documento de Identidade</div>
                    @if($kycUser->identity_document_path)
                        <span class="kycs-tag blue">Presente</span>
                    @else
                        <span class="kycs-tag red">Não Submetido</span>
                    @endif
                </div>
                <div class="kycs-card__body">
                    @if($kycUser->identity_document_path)
                        @php
                            $docPath = $kycUser->identity_document_path;
                            $isPdf = str_ends_with(strtolower($docPath), '.pdf');
                        @endphp
                        @if($isPdf)
                            <div class="kycs-doc-wrap">
                                <div class="kycs-doc-pdf">
                                    <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" stroke-width="1.5" style="margin:0 auto 0.75rem;"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
                                    <div style="font-size:0.8rem;color:#64748b;margin-bottom:0.75rem;">Documento em PDF</div>
                                    <a href="{{ asset('storage/'.$docPath) }}" target="_blank">
                                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>
                                        Abrir PDF
                                    </a>
                                </div>
                            </div>
                        @else
                            <div class="kycs-doc-wrap">
                                <img src="{{ asset('storage/'.$docPath) }}"
                                     alt="Documento"
                                     onclick="window.open(this.src,'_blank')">
                                <a href="{{ asset('storage/'.$docPath) }}" target="_blank" class="kycs-doc-open-link">
                                    <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>
                                    Ver em tamanho real
                                </a>
                            </div>
                        @endif
                    @else
                        <div class="kycs-doc-wrap kycs-doc-empty">
                            <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#cbd5e1" stroke-width="1.5" style="margin:0 auto 0.5rem;"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                            <div style="font-size:0.8rem;">O utilizador ainda não submeteu documento.</div>
                        </div>
                    @endif
                </div>
            </div>

            {{-- SELFIE --}}
            @if($kycUser->profile_photo_path)
            <div class="kycs-card">
                <div class="kycs-card__head">
                    <div class="kycs-card__title">📷 Selfie — Rosto</div>
                    <span class="kycs-tag purple">Presente</span>
                </div>
                <div class="kycs-selfie-row">
                    <img src="{{ asset('storage/'.$kycUser->profile_photo_path) }}"
                         alt="Selfie"
                         class="kycs-selfie-img"
                         onclick="window.open(this.src,'_blank')">
                    <div class="kycs-selfie-info">
                        <strong>Verificação Visual</strong>
                        <div style="margin-top:3px;">Compara o rosto acima com a fotografia do documento à esquerda.</div>
                        <ul>
                            <li>Rosto claramente visível</li>
                            <li>Sem óculos escuros ou boné</li>
                            <li>Foto não parece editada</li>
                            <li>Corresponde ao BI submetido</li>
                        </ul>
                    </div>
                </div>
            </div>
            @endif

            {{-- PAINEL DE DECISÃO --}}
            @if(!$kycUser->identity_verified_at && $kycUser->identity_document_path)
                <div class="kycs-decision">
                    <h3 class="kycs-decision__title">Decisão de Verificação</h3>
                    <p class="kycs-decision__sub">Após rever documento e selfie, aprova ou rejeita. A ação fica registada no Audit Trail de forma permanente.</p>

                    <div class="kycs-decision__actions">
                        {{-- APROVAR --}}
                        <form method="POST" action="{{ route('admin.kyc.approve', $kycUser->id) }}"
                              onsubmit="return confirm('Confirmas a APROVAÇÃO de identidade de {{ addslashes($kycUser->full_name ?? $kycUser->email) }}?\n\nO cliente poderá realizar câmbios imediatamente.');">
                            @csrf
                            <button type="submit" class="kycs-btn-approve">
                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>
                                Aprovar Identidade
                            </button>
                        </form>

                        {{-- REJEITAR --}}
                        <form method="POST" action="{{ route('admin.kyc.reject', $kycUser->id) }}"
                              x-data="{reason:'', custom:''}"
                              @submit.prevent="
                                const finalReason = reason === '__custom__' ? custom.trim() : reason;
                                if(!finalReason){ alert('Indica o motivo da rejeição.'); return; }
                                if(confirm('Confirmas REJEIÇÃO?\\nMotivo: '+finalReason)){
                                    $el.querySelector('input[name=reason]').value = finalReason;
                                    $el.submit();
                                }
                              ">
                            @csrf
                            <input type="hidden" name="reason" value="">
                            <div class="kycs-reject-box">
                                <select x-model="reason" class="kycs-reject-select">
                                    <option value="">Selecionar motivo…</option>
                                    <option value="Documento ilegível — imagem cortada ou desfocada">📷 Documento ilegível</option>
                                    <option value="Selfie não corresponde ao documento">👤 Selfie não corresponde</option>
                                    <option value="Documento expirado">📅 Documento expirado</option>
                                    <option value="Dados pessoais incompletos ou incorretos">📝 Dados incompletos</option>
                                    <option value="Documento suspeito de falsificação">🚨 Documento suspeito</option>
                                    <option value="__custom__">✏️ Outro motivo…</option>
                                </select>
                                <template x-if="reason === '__custom__'">
                                    <input type="text" x-model="custom" placeholder="Escreve o motivo…" class="kycs-reject-custom">
                                </template>
                                <button type="submit" class="kycs-btn-reject">
                                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                                    Rejeitar & Notificar
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            @elseif($kycUser->identity_verified_at)
                <div class="kycs-approved-card">
                    <div class="kycs-approved-card__icon">
                        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
                    </div>
                    <div>
                        <div class="kycs-approved-card__title font-display">Identidade Aprovada</div>
                        <div class="kycs-approved-card__sub">Verificado em {{ $kycUser->identity_verified_at->format('d/m/Y \à\s H:i') }}. Este cliente pode realizar câmbios.</div>
                    </div>
                </div>
            @else
                <div class="kycs-warning-empty">
                    ⚠️ O cliente ainda não submeteu documento de identidade. Não é possível aprovar KYC sem documentação.
                </div>
            @endif

        </div>
    </div>
</div>

</x-app-layout>