<x-app-layout>

@php
    $user = auth()->user();

    // Stats
    $totalUsers    = \App\Models\User::count();
    $kycPendingCount = \App\Models\User::whereNotNull('identity_document_path')
                            ->whereNull('identity_verified_at')->count();
    $kycApprovedCount = \App\Models\User::whereNotNull('identity_verified_at')->count();

    $txPending  = $pendingTransactions->count();
    $txTodayVol = \App\Models\Transaction::whereDate('created_at', today())
                            ->where('status', 'completed')
                            ->sum('amount_sent');
    $txTotalVol = \App\Models\Transaction::where('status', 'completed')->sum('amount_sent');

    $unreadChats = \App\Models\ChatMessage::whereHas('sender', fn($q) => $q->where('is_admin', false))
                            ->where('is_read', false)->count();

    // KYC pendentes detalhados
    $pendingKycUsers = \App\Models\User::whereNotNull('identity_document_path')
                            ->whereNull('identity_verified_at')
                            ->orderBy('updated_at', 'desc')
                            ->limit(5)->get();

    // Últimas 5 taxas
    $rates = \App\Models\ExchangeRate::all();
@endphp

<div class="admin-app" x-data="{ sidebarOpen: false }">

<style>
:root {
    --ad-bg:           #f8fafc;
    --ad-dark:         #0f172a;
    --ad-darker:       #020617;
    --ad-accent:       #10b981;
    --ad-accent-dark:  #059669;
    --ad-danger:       #dc2626;
    --ad-warn:         #f59e0b;
    --ad-info:         #3b82f6;
    --ad-border:       #e2e8f0;
    --ad-muted:        #64748b;
    --ad-faint:        #94a3b8;
    --ad-sidebar-w:    240px;
}
.admin-app * { box-sizing:border-box; }
.admin-app { background:var(--ad-bg); min-height:100dvh; font-family:'DM Sans',sans-serif; color:#0f172a; }
.font-display { font-family:'Syne',sans-serif; }
.font-mono { font-family:'JetBrains Mono',monospace; }

/* =========== LAYOUT =========== */
.ad-layout { display:flex; min-height:100dvh; }

/* =========== SIDEBAR =========== */
.ad-sidebar {
    width:var(--ad-sidebar-w);
    background:linear-gradient(180deg, #0f172a 0%, #020617 100%);
    color:white; position:fixed; top:0; left:0; bottom:0; z-index:100;
    display:flex; flex-direction:column;
}
.ad-sidebar__logo { padding:1.25rem; border-bottom:1px solid rgba(255,255,255,0.08); display:flex; align-items:center; gap:0.75rem; }
.ad-sidebar__logo img { height:32px; width:auto; filter:brightness(0) invert(1); }
.ad-sidebar__brand { font-family:'Syne',sans-serif; font-weight:800; font-size:0.95rem; letter-spacing:-0.02em; }
.ad-sidebar__subtitle { font-size:0.55rem; font-weight:700; letter-spacing:0.15em; text-transform:uppercase; color:var(--ad-accent); margin-top:-2px; }

.ad-sidebar__user { padding:1rem 1.25rem; border-bottom:1px solid rgba(255,255,255,0.08); }
.ad-sidebar__user-box { display:flex; align-items:center; gap:0.5rem; }
.ad-sidebar__avatar { width:32px; height:32px; border-radius:50%; background:var(--ad-accent); color:white; display:flex; align-items:center; justify-content:center; font-family:'Syne',sans-serif; font-weight:800; font-size:0.75rem; overflow:hidden; }
.ad-sidebar__user-name { font-weight:600; font-size:0.8rem; }
.ad-sidebar__user-role { font-size:0.6rem; color:var(--ad-accent); font-weight:700; text-transform:uppercase; letter-spacing:0.08em; }

.ad-sidebar__nav { flex:1; padding:0.875rem 0.625rem; display:flex; flex-direction:column; gap:2px; overflow-y:auto; }
.ad-sidebar__nav-label { font-size:0.55rem; font-weight:700; letter-spacing:0.15em; text-transform:uppercase; color:rgba(255,255,255,0.3); padding:0.75rem 0.75rem 0.25rem; }
.ad-nav-item { display:flex; align-items:center; gap:0.75rem; padding:0.625rem 0.75rem; border-radius:8px; cursor:pointer; transition:all 0.15s; color:rgba(255,255,255,0.6); font-size:0.8rem; font-weight:500; text-decoration:none; border:1px solid transparent; position:relative; }
.ad-nav-item:hover { background:rgba(255,255,255,0.06); color:rgba(255,255,255,0.9); }
.ad-nav-item.active { background:rgba(16,185,129,0.15); color:var(--ad-accent); border-color:rgba(16,185,129,0.25); }
.ad-nav-item.active::before { content:''; position:absolute; left:-0.625rem; top:50%; transform:translateY(-50%); width:3px; height:16px; background:var(--ad-accent); border-radius:0 3px 3px 0; }
.ad-nav-item__icon { width:16px; height:16px; flex-shrink:0; opacity:0.7; }
.ad-nav-item.active .ad-nav-item__icon { opacity:1; }
.ad-nav-badge { margin-left:auto; background:var(--ad-danger); color:white; font-size:0.6rem; font-weight:800; padding:2px 6px; border-radius:10px; min-width:18px; text-align:center; }
.ad-nav-badge.warn { background:var(--ad-warn); }
.ad-nav-badge.info { background:var(--ad-info); }

.ad-sidebar__foot { padding:1rem 1.25rem; border-top:1px solid rgba(255,255,255,0.08); font-size:0.55rem; color:rgba(255,255,255,0.4); letter-spacing:0.08em; text-transform:uppercase; font-weight:700; text-align:center; }

/* =========== MAIN =========== */
.ad-main { flex:1; margin-left:var(--ad-sidebar-w); display:flex; flex-direction:column; }
.ad-topbar { background:white; border-bottom:1px solid var(--ad-border); padding:0.875rem 1.5rem; display:flex; align-items:center; justify-content:space-between; position:sticky; top:0; z-index:50; box-shadow:0 1px 3px rgba(0,0,0,0.03); }
.ad-topbar__title { font-family:'Syne',sans-serif; font-weight:800; font-size:1.125rem; }
.ad-topbar__sub { font-size:0.75rem; color:var(--ad-muted); margin-top:-2px; }
.ad-topbar__actions { display:flex; gap:0.5rem; align-items:center; }
.ad-topbar-btn { padding:0.5rem 0.875rem; border-radius:10px; background:white; border:1px solid var(--ad-border); color:var(--ad-muted); cursor:pointer; font-size:0.75rem; font-weight:700; transition:all 0.15s; text-decoration:none; display:inline-flex; align-items:center; gap:0.375rem; }
.ad-topbar-btn:hover { background:var(--ad-bg); color:var(--ad-dark); }
.ad-topbar-btn.primary { background:var(--ad-accent); color:white; border-color:var(--ad-accent); }
.ad-topbar-btn.primary:hover { background:var(--ad-accent-dark); }

.ad-content { flex:1; padding:1.5rem; }

/* =========== FLASH =========== */
.ad-flash { padding:0.875rem 1.125rem; border-radius:10px; font-size:0.85rem; font-weight:500; display:flex; align-items:center; gap:0.625rem; margin-bottom:1rem; }
.ad-flash.success { background:#ecfdf5; border:1px solid #a7f3d0; color:#065f46; }
.ad-flash.error { background:#fee2e2; border:1px solid #fca5a5; color:#991b1b; }

/* =========== STATS =========== */
.ad-stats { display:grid; grid-template-columns:repeat(auto-fit, minmax(220px, 1fr)); gap:1rem; margin-bottom:1.5rem; }
.ad-stat { background:white; border-radius:16px; padding:1.25rem; border:1px solid var(--ad-border); box-shadow:0 1px 3px rgba(0,0,0,0.03); position:relative; overflow:hidden; }
.ad-stat::before { content:''; position:absolute; top:0; left:0; right:0; height:3px; }
.ad-stat.stat--users::before { background:var(--ad-info); }
.ad-stat.stat--kyc::before { background:var(--ad-warn); }
.ad-stat.stat--tx::before { background:var(--ad-accent); }
.ad-stat.stat--vol::before { background:var(--ad-dark); }
.ad-stat.stat--chat::before { background:var(--ad-danger); }

.ad-stat__icon { width:36px; height:36px; border-radius:10px; display:flex; align-items:center; justify-content:center; margin-bottom:0.75rem; }
.ad-stat.stat--users .ad-stat__icon { background:#dbeafe; color:var(--ad-info); }
.ad-stat.stat--kyc .ad-stat__icon { background:#fef3c7; color:var(--ad-warn); }
.ad-stat.stat--tx .ad-stat__icon { background:#d1fae5; color:var(--ad-accent); }
.ad-stat.stat--vol .ad-stat__icon { background:#e2e8f0; color:var(--ad-dark); }
.ad-stat.stat--chat .ad-stat__icon { background:#fee2e2; color:var(--ad-danger); }

.ad-stat__label { font-size:0.65rem; font-weight:700; letter-spacing:0.1em; text-transform:uppercase; color:var(--ad-faint); margin-bottom:0.25rem; }
.ad-stat__value { font-family:'Syne',sans-serif; font-size:1.75rem; font-weight:800; letter-spacing:-0.02em; line-height:1.1; }
.ad-stat__sub { font-size:0.7rem; color:var(--ad-muted); margin-top:0.25rem; }
.ad-stat__cta { display:inline-flex; align-items:center; gap:0.25rem; font-size:0.7rem; font-weight:700; color:var(--ad-accent); margin-top:0.5rem; text-decoration:none; }
.ad-stat__cta:hover { color:var(--ad-accent-dark); }

/* =========== PANEL =========== */
.ad-panels { display:grid; grid-template-columns:2fr 1fr; gap:1.25rem; }
@media(max-width:1024px) { .ad-panels { grid-template-columns:1fr; } }

.ad-panel { background:white; border-radius:16px; border:1px solid var(--ad-border); overflow:hidden; margin-bottom:1.25rem; box-shadow:0 1px 3px rgba(0,0,0,0.03); }
.ad-panel__head { padding:1rem 1.25rem; border-bottom:1px solid var(--ad-border); display:flex; align-items:center; justify-content:space-between; background:#fcfcfd; }
.ad-panel__title { font-family:'Syne',sans-serif; font-size:0.875rem; font-weight:800; display:flex; align-items:center; gap:0.5rem; }
.ad-panel__count { background:var(--ad-bg); color:var(--ad-muted); padding:2px 8px; border-radius:20px; font-size:0.65rem; font-weight:800; }
.ad-panel__link { font-size:0.7rem; font-weight:700; color:var(--ad-accent); text-decoration:none; }
.ad-panel__link:hover { color:var(--ad-accent-dark); }

/* =========== TX ROW =========== */
.ad-tx-row { padding:0.875rem 1.25rem; border-bottom:1px solid #f1f5f9; display:flex; align-items:center; gap:0.875rem; text-decoration:none; color:inherit; transition:background 0.15s; }
.ad-tx-row:last-child { border-bottom:none; }
.ad-tx-row:hover { background:var(--ad-bg); }
.ad-tx-row__badge { width:38px; height:38px; border-radius:10px; display:flex; align-items:center; justify-content:center; flex-shrink:0; font-size:1rem; }
.ad-tx-row__badge.pending { background:#fef3c7; color:var(--ad-warn); }
.ad-tx-row__badge.processing { background:#dbeafe; color:var(--ad-info); }
.ad-tx-row__badge.awaiting_payment { background:#fef3c7; color:var(--ad-warn); }
.ad-tx-row__info { flex:1; min-width:0; }
.ad-tx-row__ref { font-family:'Syne',sans-serif; font-size:0.825rem; font-weight:700; }
.ad-tx-row__meta { font-size:0.7rem; color:var(--ad-muted); margin-top:1px; }
.ad-tx-row__amount { font-family:'Syne',sans-serif; font-size:0.9rem; font-weight:800; text-align:right; }
.ad-tx-row__currency { font-size:0.7rem; color:var(--ad-accent-dark); font-weight:600; text-align:right; margin-top:1px; }
.ad-badge-status { display:inline-block; font-size:0.6rem; font-weight:800; padding:2px 7px; border-radius:20px; text-transform:uppercase; letter-spacing:0.08em; margin-top:2px; }
.ad-badge-status.pending, .ad-badge-status.awaiting_payment { background:#fef3c7; color:#92400e; }
.ad-badge-status.processing { background:#dbeafe; color:#1e40af; }

/* =========== KYC ROW =========== */
.ad-kyc-row { padding:0.875rem 1.25rem; border-bottom:1px solid #f1f5f9; display:flex; align-items:center; gap:0.75rem; text-decoration:none; color:inherit; transition:background 0.15s; }
.ad-kyc-row:last-child { border-bottom:none; }
.ad-kyc-row:hover { background:var(--ad-bg); }
.ad-kyc-row__avatar { width:36px; height:36px; border-radius:50%; background:#d1fae5; color:#064e3b; display:flex; align-items:center; justify-content:center; font-family:'Syne',sans-serif; font-weight:800; font-size:0.7rem; overflow:hidden; flex-shrink:0; }
.ad-kyc-row__info { flex:1; min-width:0; }
.ad-kyc-row__name { font-size:0.8rem; font-weight:700; }
.ad-kyc-row__email { font-size:0.68rem; color:var(--ad-faint); }
.ad-kyc-row__time { font-size:0.65rem; color:var(--ad-warn); font-weight:700; margin-top:1px; }

/* =========== RATES =========== */
.ad-rate-card { padding:0.875rem 1.125rem; border-bottom:1px solid #f1f5f9; display:flex; align-items:center; justify-content:space-between; }
.ad-rate-card:last-child { border-bottom:none; }
.ad-rate-card__pair { font-family:'Syne',sans-serif; font-weight:800; font-size:0.95rem; }
.ad-rate-card__value { font-family:'Syne',sans-serif; font-size:1.05rem; font-weight:800; color:var(--ad-accent-dark); }
.ad-rate-card__status { font-size:0.58rem; font-weight:800; text-transform:uppercase; letter-spacing:0.08em; padding:2px 7px; border-radius:20px; margin-left:0.5rem; }
.ad-rate-card__status.active { background:#d1fae5; color:#065f46; }
.ad-rate-card__status.inactive { background:#fee2e2; color:#991b1b; }

/* =========== EMPTY =========== */
.ad-empty { padding:2.5rem 1.5rem; text-align:center; color:var(--ad-faint); }
.ad-empty__icon { font-size:2.5rem; margin-bottom:0.5rem; opacity:0.5; }
.ad-empty__text { font-size:0.825rem; font-weight:600; }

/* =========== QUICK ACTIONS =========== */
.ad-quick-grid { display:grid; grid-template-columns:repeat(2, 1fr); gap:0.625rem; padding:1.125rem; }
.ad-quick-btn { padding:1rem; background:#fcfcfd; border:1px solid var(--ad-border); border-radius:12px; cursor:pointer; text-decoration:none; color:inherit; display:flex; flex-direction:column; align-items:center; gap:0.375rem; transition:all 0.15s; text-align:center; }
.ad-quick-btn:hover { border-color:var(--ad-accent); background:white; transform:translateY(-1px); box-shadow:0 4px 12px rgba(0,0,0,0.05); }
.ad-quick-btn__icon { font-size:1.5rem; }
.ad-quick-btn__label { font-family:'Syne',sans-serif; font-size:0.7rem; font-weight:800; letter-spacing:0.03em; }

/* =========== MOBILE =========== */
.ad-mobile-toggle { display:none; background:white; border:1px solid var(--ad-border); padding:0.5rem; border-radius:10px; cursor:pointer; color:var(--ad-dark); }

@media(max-width:1023px) {
    .ad-sidebar { transform:translateX(-100%); transition:transform 0.3s; }
    .ad-sidebar.open { transform:translateX(0); }
    .ad-main { margin-left:0; }
    .ad-mobile-toggle { display:flex; }
    .ad-topbar { padding:0.75rem 1rem; }
    .ad-content { padding:1rem; }
    .ad-stats { grid-template-columns:1fr 1fr; gap:0.625rem; }
    .ad-stat { padding:0.875rem; }
    .ad-stat__value { font-size:1.35rem; }
}
@media(max-width:600px) {
    .ad-stats { grid-template-columns:1fr; }
    .ad-quick-grid { grid-template-columns:1fr 1fr; }
}
</style>

<div class="ad-layout">

    {{-- ============ SIDEBAR ============ --}}
    <aside class="ad-sidebar" :class="{open:sidebarOpen}">
        <div class="ad-sidebar__logo">
            <img src="{{ asset('assets/images/logos/logo1.png') }}" alt="KwanzaSafe" onerror="this.style.display='none'">
            <div>
                <div class="ad-sidebar__brand">KwanzaSafe</div>
                <div class="ad-sidebar__subtitle">Admin Control</div>
            </div>
        </div>

        <div class="ad-sidebar__user">
            <div class="ad-sidebar__user-box">
                <div class="ad-sidebar__avatar">
                    {{ strtoupper(substr($user->full_name ?? $user->email, 0, 1)) }}
                </div>
                <div style="min-width:0;flex:1;">
                    <div class="ad-sidebar__user-name">{{ Str::limit($user->full_name ?? 'Admin', 18) }}</div>
                    <div class="ad-sidebar__user-role">Administrador</div>
                </div>
            </div>
        </div>

        <nav class="ad-sidebar__nav">
            <div class="ad-sidebar__nav-label">Operações</div>

            <a href="{{ route('admin.dashboard') }}" class="ad-nav-item active">
                <svg class="ad-nav-item__icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"/></svg>
                Visão Geral
            </a>

            <a href="{{ route('admin.kyc.index') }}" class="ad-nav-item">
                <svg class="ad-nav-item__icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V8a2 2 0 00-2-2h-5m-4 0V5a2 2 0 114 0v1m-4 0a2 2 0 104 0m-5 8a2 2 0 100-4 2 2 0 000 4zm0 0c1.306 0 2.417.835 2.83 2M9 14a3.001 3.001 0 00-2.83 2M15 11h3m-3 4h2"/></svg>
                KYC — Verificação
                @if($kycPendingCount > 0)
                    <span class="ad-nav-badge warn">{{ $kycPendingCount }}</span>
                @endif
            </a>

            <a href="#tx-pending" class="ad-nav-item">
                <svg class="ad-nav-item__icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4"/></svg>
                Transações
                @if($txPending > 0)
                    <span class="ad-nav-badge info">{{ $txPending }}</span>
                @endif
            </a>

            <a href="{{ route('admin.rates.index') }}" class="ad-nav-item">
                <svg class="ad-nav-item__icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                Taxas de Câmbio
            </a>

            <div class="ad-sidebar__nav-label">Segurança</div>

            <a href="{{ route('admin.audit.index') }}" class="ad-nav-item">
                <svg class="ad-nav-item__icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
                Audit Trail
            </a>

            <div class="ad-sidebar__nav-label">Área Cliente</div>

            <a href="{{ route('dashboard') }}" class="ad-nav-item">
                <svg class="ad-nav-item__icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
                Voltar ao Cliente
            </a>

            <form method="POST" action="{{ route('logout') }}" style="margin-top:0.5rem;">
                @csrf
                <button type="submit" class="ad-nav-item" style="width:100%;background:none;border:none;text-align:left;cursor:pointer;color:#fca5a5;">
                    <svg class="ad-nav-item__icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/></svg>
                    Sair
                </button>
            </form>
        </nav>

        <div class="ad-sidebar__foot">
            KwanzaSafe © 2026<br>Huambo, Angola
        </div>
    </aside>

    {{-- ============ MAIN ============ --}}
    <main class="ad-main">

        <header class="ad-topbar">
            <div style="display:flex;align-items:center;gap:0.75rem;">
                <button class="ad-mobile-toggle" @click="sidebarOpen=!sidebarOpen">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 12h16M4 18h16"/></svg>
                </button>
                <div>
                    <div class="ad-topbar__title font-display">Centro de Comando</div>
                    <div class="ad-topbar__sub">Bem-vindo de volta, {{ Str::limit($user->full_name ?? 'Admin', 24) }}</div>
                </div>
            </div>
            <div class="ad-topbar__actions">
                <a href="{{ route('admin.audit.index') }}" class="ad-topbar-btn">
                    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
                    Auditoria
                </a>
                <a href="{{ route('admin.kyc.index') }}" class="ad-topbar-btn primary">
                    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
                    Aprovar KYC @if($kycPendingCount) ({{ $kycPendingCount }}) @endif
                </a>
            </div>
        </header>

        <div class="ad-content">

            {{-- Flash --}}
            @if(session('success'))
                <div class="ad-flash success">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                    {{ session('success') }}
                </div>
            @endif

            {{-- =========== STATS =========== --}}
            <div class="ad-stats">
                <div class="ad-stat stat--users">
                    <div class="ad-stat__icon">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
                    </div>
                    <div class="ad-stat__label">Total Utilizadores</div>
                    <div class="ad-stat__value font-display">{{ number_format($totalUsers) }}</div>
                    <div class="ad-stat__sub">{{ $kycApprovedCount }} aprovados • {{ $kycPendingCount }} pendentes</div>
                </div>

                <div class="ad-stat stat--kyc">
                    <div class="ad-stat__icon">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M10 6H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V8a2 2 0 00-2-2h-5m-4 0V5a2 2 0 114 0v1"/></svg>
                    </div>
                    <div class="ad-stat__label">KYC Pendentes</div>
                    <div class="ad-stat__value font-display" style="color:var(--ad-warn);">{{ number_format($kycPendingCount) }}</div>
                    @if($kycPendingCount > 0)
                        <a href="{{ route('admin.kyc.index') }}" class="ad-stat__cta">
                            Rever agora
                            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                        </a>
                    @else
                        <div class="ad-stat__sub">✓ Nenhum a rever</div>
                    @endif
                </div>

                <div class="ad-stat stat--tx">
                    <div class="ad-stat__icon">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4"/></svg>
                    </div>
                    <div class="ad-stat__label">Transações Pendentes</div>
                    <div class="ad-stat__value font-display" style="color:var(--ad-info);">{{ number_format($txPending) }}</div>
                    @if($txPending > 0)
                        <div class="ad-stat__sub">A aguardar processamento</div>
                    @else
                        <div class="ad-stat__sub">✓ Nenhuma pendente</div>
                    @endif
                </div>

                <div class="ad-stat stat--vol">
                    <div class="ad-stat__icon">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                    </div>
                    <div class="ad-stat__label">Volume Hoje</div>
                    <div class="ad-stat__value font-display">{{ number_format($txTodayVol, 0, ',', '.') }}</div>
                    <div class="ad-stat__sub">Total: {{ number_format($txTotalVol, 0, ',', '.') }} processados</div>
                </div>

                <div class="ad-stat stat--chat">
                    <div class="ad-stat__icon">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/></svg>
                    </div>
                    <div class="ad-stat__label">Mensagens Por Ler</div>
                    <div class="ad-stat__value font-display" style="color:var(--ad-danger);">{{ number_format($unreadChats) }}</div>
                    @if($unreadChats > 0)
                        <div class="ad-stat__sub">De clientes — responder ASAP</div>
                    @else
                        <div class="ad-stat__sub">✓ Tudo em dia</div>
                    @endif
                </div>
            </div>

            {{-- =========== AÇÕES RÁPIDAS =========== --}}
            <div class="ad-panel">
                <div class="ad-panel__head">
                    <div class="ad-panel__title font-display">⚡ Ações Rápidas</div>
                </div>
                <div class="ad-quick-grid">
                    <a href="{{ route('admin.kyc.index') }}" class="ad-quick-btn">
                        <div class="ad-quick-btn__icon">🪪</div>
                        <div class="ad-quick-btn__label">Rever KYC</div>
                    </a>
                    <a href="{{ route('admin.rates.index') }}" class="ad-quick-btn">
                        <div class="ad-quick-btn__icon">💱</div>
                        <div class="ad-quick-btn__label">Atualizar Taxas</div>
                    </a>
                    <a href="{{ route('admin.audit.index') }}" class="ad-quick-btn">
                        <div class="ad-quick-btn__icon">🛡️</div>
                        <div class="ad-quick-btn__label">Audit Trail</div>
                    </a>
                    <a href="{{ route('dashboard') }}" class="ad-quick-btn">
                        <div class="ad-quick-btn__icon">👤</div>
                        <div class="ad-quick-btn__label">Vista Cliente</div>
                    </a>
                </div>
            </div>

            {{-- =========== PAINEIS LADO A LADO =========== --}}
            <div class="ad-panels">

                {{-- TRANSAÇÕES PENDENTES --}}
                <div>
                    <div class="ad-panel" id="tx-pending">
                        <div class="ad-panel__head">
                            <div class="ad-panel__title font-display">
                                💸 Transações a Processar
                                <span class="ad-panel__count">{{ $pendingTransactions->count() }}</span>
                            </div>
                        </div>

                        @if($pendingTransactions->isEmpty())
                            <div class="ad-empty">
                                <div class="ad-empty__icon">✅</div>
                                <div class="ad-empty__text">Nenhuma transação pendente</div>
                            </div>
                        @else
                            @foreach($pendingTransactions as $tx)
                                <a href="{{ route('admin.transaction.show', $tx->id) }}" class="ad-tx-row">
                                    <div class="ad-tx-row__badge {{ $tx->status }}">
                                        @if($tx->status === 'processing') ⏳
                                        @elseif(in_array($tx->status, ['pending','awaiting_payment'])) 💰
                                        @else 📋 @endif
                                    </div>
                                    <div class="ad-tx-row__info">
                                        <div class="ad-tx-row__ref">#{{ $tx->reference_id }}</div>
                                        <div class="ad-tx-row__meta">
                                            {{ optional($tx->user)->email ?? '—' }} • {{ $tx->created_at->diffForHumans() }}
                                        </div>
                                        <span class="ad-badge-status {{ $tx->status }}">{{ str_replace('_',' ', $tx->status) }}</span>
                                    </div>
                                    <div>
                                        <div class="ad-tx-row__amount">{{ number_format($tx->amount_sent, 2, ',', '.') }} {{ $tx->currency_from }}</div>
                                        <div class="ad-tx-row__currency">{{ number_format($tx->amount_received, 0, ',', '.') }} Kz</div>
                                    </div>
                                </a>
                            @endforeach
                        @endif
                    </div>
                </div>

                {{-- SIDEBAR: KYC + TAXAS --}}
                <div>
                    {{-- KYC PENDENTE --}}
                    <div class="ad-panel">
                        <div class="ad-panel__head">
                            <div class="ad-panel__title font-display">
                                🪪 KYC a Rever
                                <span class="ad-panel__count">{{ $kycPendingCount }}</span>
                            </div>
                            <a href="{{ route('admin.kyc.index') }}" class="ad-panel__link">Todos →</a>
                        </div>

                        @if($pendingKycUsers->isEmpty())
                            <div class="ad-empty">
                                <div class="ad-empty__icon">✅</div>
                                <div class="ad-empty__text">Tudo em dia</div>
                            </div>
                        @else
                            @foreach($pendingKycUsers as $u)
                                <a href="{{ route('admin.kyc.show', $u->id) }}" class="ad-kyc-row">
                                    <div class="ad-kyc-row__avatar">
                                        @if($u->profile_photo_path)
                                            <img src="{{ asset('storage/'.$u->profile_photo_path) }}" style="width:100%;height:100%;object-fit:cover;">
                                        @else
                                            {{ strtoupper(substr($u->full_name ?? $u->email, 0, 1)) }}
                                        @endif
                                    </div>
                                    <div class="ad-kyc-row__info">
                                        <div class="ad-kyc-row__name">{{ Str::limit($u->full_name ?? $u->email, 20) }}</div>
                                        <div class="ad-kyc-row__email">{{ Str::limit($u->email, 22) }}</div>
                                        <div class="ad-kyc-row__time">Enviou {{ $u->updated_at->diffForHumans() }}</div>
                                    </div>
                                </a>
                            @endforeach
                        @endif
                    </div>

                    {{-- TAXAS ATIVAS --}}
                    <div class="ad-panel">
                        <div class="ad-panel__head">
                            <div class="ad-panel__title font-display">💱 Taxas Ativas</div>
                            <a href="{{ route('admin.rates.index') }}" class="ad-panel__link">Gerir →</a>
                        </div>
                        @foreach($rates as $r)
                            <div class="ad-rate-card">
                                <div>
                                    <div class="ad-rate-card__pair">{{ $r->currency_from }} → AOA</div>
                                    <div style="font-size:0.65rem;color:var(--ad-faint);margin-top:2px;">
                                        Atualizada {{ $r->updated_at->diffForHumans() }}
                                    </div>
                                </div>
                                <div>
                                    <span class="ad-rate-card__value">{{ number_format($r->rate, 2, ',', '.') }}</span>
                                    <span class="ad-rate-card__status {{ $r->is_active ? 'active' : 'inactive' }}">
                                        {{ $r->is_active ? 'Ativa' : 'Inativa' }}
                                    </span>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>

            </div>

            <div style="text-align:center;padding:1rem 0 0.5rem;font-size:0.6rem;color:var(--ad-faint);font-family:'JetBrains Mono',monospace;letter-spacing:0.08em;text-transform:uppercase;">
                KwanzaSafe Admin • BNA Regulated • AML Compliant • {{ now()->format('d/m/Y H:i') }}
            </div>
        </div>
    </main>
</div>

</div>
</x-app-layout>
