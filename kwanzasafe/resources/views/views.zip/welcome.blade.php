<!DOCTYPE html>
<html lang="pt-AO" class="scroll-smooth">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    
    <title>KwanzaSafe | Câmbio Digital e Transferências em Angola</title>
    <meta name="description" content="A KwanzaSafe é a plataforma líder em Huambo para conversão de Euros e Reais para Kwanzas. Segurança bancária, taxas reais e transparência total.">
    <meta name="keywords" content="Câmbio Angola, Euro para Kwanza, Real para Kwanza, Fintech Angola, KwanzaSafe, Huambo, Transferências Seguras">
    <meta name="author" content="Edson Chimuco">
    <meta name="robots" content="index, follow">
    
    <meta property="og:title" content="KwanzaSafe | Tecnologia que Transforma">
    <meta property="og:description" content="Converta as suas divisas com segurança máxima e rapidez em Angola.">
    <meta property="og:image" content="{{ asset('assets/images/logos/logo2.PNG') }}">
    <meta property="og:url" content="https://kwanzasafe.com">
    <meta property="og:type" content="website">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    
    <script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>
    @vite(['resources/css/app.css', 'resources/js/app.js'])

    <style>
        [x-cloak] { display: none !important; }
        body { font-family: 'Inter', sans-serif; -webkit-font-smoothing: antialiased; }
        
        /* Paleta de Cores Institucional */
        .bg-ks-emerald { background-color: #064e3b; }
        .text-ks-emerald { color: #064e3b; }
        .border-ks-emerald { border-color: #064e3b; }
        .focus-ks:focus { border-color: #064e3b; ring-color: rgba(6, 78, 59, 0.2); }

        /* Menu Mobile 100vh Blindado */
        .mobile-menu-active { overflow: hidden !important; height: 100vh !important; width: 100vw !important; position: fixed !important; }
        
        /* Utilitários de Design */
        .glass-effect { background: rgba(255, 255, 255, 0.8); backdrop-filter: blur(15px); }
        .text-gradient { background: linear-gradient(to right, #064e3b, #10b981); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
        .section-padding { padding-top: 120px; padding-bottom: 120px; }
        
        /* Animações */
        @keyframes float { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-15px); } }
        .animate-float { animation: float 6s ease-in-out infinite; }
    </style>
</head>
<body class="bg-white text-slate-900" x-data="{ mobileMenu: false, activeFaq: 1 }" :class="{ 'mobile-menu-active': mobileMenu }">

    <nav class="fixed w-full h-24 z-[100] bg-white/95 backdrop-blur-md border-b border-slate-100 flex items-center transition-all duration-300">
        <div class="max-w-7xl mx-auto px-6 w-full flex justify-between items-center">
            
            <div class="flex items-center">
                <a href="/" class="transition transform hover:scale-105">
                    <img src="{{ asset('assets/images/logos/logo.png') }}" alt="KwanzaSafe" class="h-12 w-auto block sm:hidden">
                    <img src="{{ asset('assets/images/logos/logo1.png') }}" alt="KwanzaSafe" class="h-16 w-auto hidden sm:block md:hidden">
                    <img src="{{ asset('assets/images/logos/logo2.PNG') }}" alt="KwanzaSafe" class="h-28 w-auto hidden md:block">
                </a>
            </div>
            
            <div class="hidden md:flex items-center gap-10">
                <div class="flex items-center gap-8 text-sm font-bold text-slate-500 uppercase tracking-widest">
                    <a href="#como-funciona" class="hover:text-ks-emerald transition">Processo</a>
                    <a href="#seguranca" class="hover:text-ks-emerald transition">Segurança</a>
                    <a href="#depoimentos" class="hover:text-ks-emerald transition">Clientes</a>
                </div>
                <div class="h-8 w-px bg-slate-200"></div>
                @auth
                    <a href="{{ url('/dashboard') }}" class="text-sm font-black text-ks-emerald border-2 border-ks-emerald px-6 py-3 rounded-2xl hover:bg-ks-emerald hover:text-white transition">DASHBOARD</a>
                @else
                    <a href="{{ route('login') }}" class="text-sm font-bold text-slate-600">Entrar</a>
                    <a href="{{ route('register') }}" class="bg-ks-emerald text-white px-10 py-4 rounded-2xl font-black text-sm uppercase tracking-[0.1em] shadow-2xl shadow-emerald-900/30 hover:scale-105 transition transform active:scale-95">
                        Criar Conta
                    </a>
                @endauth
            </div>

            <button class="md:hidden p-4 bg-slate-50 rounded-2xl text-slate-900 focus:outline-none" @click="mobileMenu = true">
                <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M4 6h16M4 12h16m-7 6h7"></path>
                </svg>
            </button>
        </div>

        <div x-show="mobileMenu" 
             x-cloak 
             x-transition:enter="transition ease-out duration-300"
             x-transition:enter-start="translate-x-full"
             x-transition:enter-end="translate-x-0"
             x-transition:leave="transition ease-in duration-200"
             x-transition:leave-start="translate-x-0"
             x-transition:leave-end="translate-x-full"
             class="fixed inset-0 z-[2000] bg-white flex flex-col w-screen h-screen overflow-hidden">
            
            <div class="h-24 px-8 flex justify-between items-center border-b border-slate-50">
                <img src="{{ asset('assets/images/logos/logo.png') }}" class="h-10 w-auto" alt="Logo">
                <button @click="mobileMenu = false" class="p-4 bg-slate-100 rounded-full text-slate-900">
                    <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M6 18L18 6M6 6l12 12"></path></svg>
                </button>
            </div>

            <nav class="flex-1 flex flex-col justify-center px-10 space-y-12">
                <div class="space-y-8 text-center sm:text-left">
                    <a href="#como-funciona" @click="mobileMenu = false" class="block text-5xl font-black text-slate-900 tracking-tighter italic hover:text-ks-emerald transition">O Processo</a>
                    <a href="#depoimentos" @click="mobileMenu = false" class="block text-5xl font-black text-slate-900 tracking-tighter italic hover:text-ks-emerald transition">Feedback</a>
                    <a href="#faq" @click="mobileMenu = false" class="block text-5xl font-black text-slate-900 tracking-tighter italic hover:text-ks-emerald transition">Dúvidas</a>
                    <a href="https://wa.me/244931719207" class="block text-5xl font-black text-green-600 tracking-tighter italic">Suporte</a>
                </div>

                <div class="grid gap-4 pt-8">
                    <a href="{{ route('login') }}" class="w-full py-6 text-center text-xl font-bold text-slate-600 bg-slate-50 rounded-[2rem]">Entrar na Conta</a>
                    <a href="{{ route('register') }}" class="w-full py-6 text-center text-xl font-black text-white bg-ks-emerald rounded-[2rem] shadow-2xl shadow-emerald-900/20">Registo Grátis</a>
                </div>
            </nav>

            <div class="p-10 text-center bg-slate-50">
                <p class="text-[10px] font-black text-slate-400 uppercase tracking-[0.5em]">KwanzaSafe — Huambo, Angola</p>
            </div>
        </div>
    </nav>

    <section class="relative pt-60 pb-32 hero-gradient overflow-hidden">
        <div class="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-24 items-center relative z-10">
            <div class="space-y-12 text-center lg:text-left">
                <div class="inline-flex items-center gap-3 bg-white border border-slate-200 px-6 py-3 rounded-full shadow-sm mx-auto lg:mx-0">
                    <span class="flex h-3 w-3 rounded-full bg-green-500 animate-ping"></span>
                    <span class="text-xs font-black text-slate-600 uppercase tracking-widest">Plataforma Auditada 2026</span>
                </div>

                <h1 class="text-6xl sm:text-8xl font-black text-slate-900 leading-[0.9] tracking-tighter">
                    Câmbio de <br><span class="text-ks-emerald italic underline decoration-ks-emerald/20">Divisas</span> em Angola.
                </h1>
                
                <p class="text-xl text-slate-500 leading-relaxed max-w-xl mx-auto lg:mx-0 font-medium">
                    A forma mais rápida e segura de converter Euros e Reais para Kwanzas através de Huambo. Tecnologia angolana para o mundo.
                </p>

                <div class="flex flex-col sm:flex-row justify-center lg:justify-start gap-6 pt-6">
                    <a href="{{ route('register') }}" class="bg-ks-emerald text-white px-12 py-7 rounded-3xl font-black text-xl shadow-[0_25px_50px_-12px_rgba(6,78,59,0.3)] hover:scale-105 transition flex items-center justify-center gap-4">
                        Criar Conta Agora
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M14 5l7 7m0 0l-7 7m7-7H3" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    </a>
                </div>
            </div>

            <div class="relative hidden lg:block">
                <div class="absolute -inset-10 bg-ks-emerald/10 rounded-full blur-[100px] animate-pulse"></div>
                <div class="relative bg-white p-5 rounded-[4rem] shadow-2xl border border-slate-100 rotate-2 hover:rotate-0 transition duration-1000">
                    <img src="{{ asset('assets/images/banners/dashboard-user.jpeg') }}" alt="Interface KwanzaSafe" class="rounded-[3rem] w-full h-auto">
                    <div class="absolute -bottom-10 -left-10 bg-white p-8 rounded-3xl shadow-2xl border border-slate-50 flex items-center gap-4 animate-float">
                        <div class="w-14 h-14 bg-green-50 rounded-2xl flex items-center justify-center text-green-600">
                            <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" stroke-width="2"/></svg>
                        </div>
                        <div>
                            <p class="text-xs font-black text-slate-400 uppercase tracking-widest">Atendimento Humano</p>
                            <p class="text-xl font-black text-slate-800 tracking-tighter">Suporte 24/7</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="como-funciona" class="section-padding bg-white relative overflow-hidden">
        <div class="max-w-7xl mx-auto px-6">
            <div class="text-center max-w-3xl mx-auto mb-32">
                <span class="text-ks-emerald font-black text-xs uppercase tracking-[0.4em] mb-4 block">Workflow</span>
                <h2 class="text-5xl font-black text-slate-900 tracking-tighter italic">Simplicidade que gera confiança.</h2>
            </div>

            <div class="space-y-64">
                <div class="grid lg:grid-cols-2 gap-24 items-center">
                    <div class="space-y-8 relative">
                        <div class="text-[12rem] font-black text-slate-50 absolute -top-40 -left-20 -z-10 select-none">01</div>
                        <h3 class="text-4xl font-black text-slate-900 tracking-tight">Cálculo e Simulação</h3>
                        <p class="text-lg text-slate-500 leading-relaxed font-medium">
                            A nossa calculadora integrada utiliza taxas reais de mercado. Informe o montante que deseja converter e veja instantaneamente o valor que será creditado na sua carteira. Sem surpresas no final.
                        </p>
                        <ul class="space-y-4">
                            <li class="flex items-center gap-3 font-bold text-slate-700">
                                <div class="w-6 h-6 bg-green-100 text-green-600 rounded-full flex items-center justify-center text-[10px]">✔</div>
                                Transparência de Taxas
                            </li>
                            <li class="flex items-center gap-3 font-bold text-slate-700">
                                <div class="w-6 h-6 bg-green-100 text-green-600 rounded-full flex items-center justify-center text-[10px]">✔</div>
                                Atualização em Tempo Real
                            </li>
                        </ul>
                    </div>
                    <div class="relative p-4 bg-slate-50 rounded-[4rem] shadow-inner">
                        <img src="{{ asset('assets/images/banners/dashboard-user.jpeg') }}" alt="Simulação KwanzaSafe" class="rounded-[3rem] shadow-2xl">
                    </div>
                </div>

                <div class="grid lg:grid-cols-2 gap-24 items-center">
                    <div class="order-2 lg:order-1 flex justify-center">
                        <div class="relative group">
                            <div class="absolute -inset-4 bg-ks-emerald/5 rounded-[4rem] group-hover:rotate-6 transition duration-500"></div>
                            <img src="{{ asset('assets/images/banners/historico-mobile.jpeg') }}" alt="Histórico Móvel" class="relative rounded-[3.5rem] shadow-2xl border-[12px] border-white max-w-sm">
                        </div>
                    </div>
                    <div class="order-1 lg:order-2 space-y-8 relative">
                        <div class="text-[12rem] font-black text-slate-50 absolute -top-40 -right-20 -z-10 select-none">02</div>
                        <h3 class="text-4xl font-black text-slate-900 tracking-tight">Controlo na Palma da Mão</h3>
                        <p class="text-lg text-slate-500 leading-relaxed font-medium">
                            Cada passo da sua operação é documentado. Acompanhe o estado da validação do seu talão e consulte transações passadas a partir do seu telemóvel com total clareza.
                        </p>
                    </div>
                </div>

                <div class="grid lg:grid-cols-2 gap-24 items-center">
                    <div class="space-y-8 relative">
                        <div class="text-[12rem] font-black text-slate-50 absolute -top-40 -left-20 -z-10 select-none">03</div>
                        <h3 class="text-4xl font-black text-slate-900 tracking-tight">Auditado por Humanos</h3>
                        <p class="text-lg text-slate-500 leading-relaxed font-medium">
                            Não somos apenas algoritmos. A nossa equipa financeira valida cada talão manualmente para garantir que o seu dinheiro chega ao destino certo com segurança bancária.
                        </p>
                        <a href="https://wa.me/244931719207" class="inline-flex items-center gap-4 text-green-600 font-black text-xl hover:underline">
                            Suporte Direto WhatsApp
                            <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                        </a>
                    </div>
                    <div class="flex justify-center">
                        <img src="{{ asset('assets/images/banners/chatmobile.png') }}" alt="Suporte KwanzaSafe" class="rounded-[3.5rem] shadow-2xl border-[12px] border-white max-w-sm rotate-2">
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="depoimentos" class="section-padding bg-slate-950 text-white relative overflow-hidden">
        <div class="absolute -right-20 -top-20 w-96 h-96 bg-ks-emerald rounded-full blur-[150px] opacity-20"></div>
        
        <div class="max-w-7xl mx-auto px-6 relative z-10">
            <div class="text-center max-w-3xl mx-auto mb-24">
                <h2 class="text-5xl font-black tracking-tighter italic">Vozes de quem confia na <span class="text-ks-emerald">KwanzaSafe.</span></h2>
            </div>

            <div class="grid md:grid-cols-3 gap-10">
                <div class="bg-white/5 backdrop-blur-xl p-12 rounded-[4rem] border border-white/10 flex flex-col justify-between">
                    <div>
                        <div class="flex gap-1 text-yellow-400 mb-8">
                            @for($i=0;$i<5;$i++) <svg class="w-5 h-5 fill-current" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg> @endfor
                        </div>
                        <p class="text-slate-400 italic text-xl leading-relaxed mb-12">"Impressionado com a rapidez. Troquei Euros por Kwanzas no Huambo e o saldo estava disponível em menos de 1 hora."</p>
                    </div>
                    <div>
                        <p class="font-black text-white text-2xl tracking-tight italic">Mateus João</p>
                        <p class="text-xs font-bold text-ks-emerald uppercase tracking-widest mt-1">Auditado & Verificado</p>
                    </div>
                </div>

                <div class="bg-ks-emerald/10 p-12 rounded-[4rem] border border-ks-emerald/20 flex flex-col justify-between mt-12 md:mt-24">
                    <div>
                        <p class="text-slate-400 italic text-xl leading-relaxed mb-12">"O design é fantástico e muito simples de usar. Finalmente temos uma solução digital real para câmbio em Angola."</p>
                    </div>
                    <div>
                        <p class="font-black text-white text-2xl tracking-tight italic">Sandra Bento</p>
                        <p class="text-xs font-bold text-ks-emerald uppercase tracking-widest mt-1">Cliente Gold</p>
                    </div>
                </div>

                <div class="bg-white/5 backdrop-blur-xl p-12 rounded-[4rem] border border-white/10 flex flex-col justify-between">
                    <div>
                        <p class="text-slate-400 italic text-xl leading-relaxed mb-12">"Precisei de ajuda com o upload do talão e o suporte pelo WhatsApp foi imediato. Muito profissional."</p>
                    </div>
                    <div>
                        <p class="font-black text-white text-2xl tracking-tight italic">Vasco Simbal</p>
                        <p class="text-xs font-bold text-ks-emerald uppercase tracking-widest mt-1">Negócios Digitais</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="faq" class="section-padding bg-white">
        <div class="max-w-4xl mx-auto px-6">
            <h2 class="text-5xl font-black text-center mb-24 tracking-tighter italic">Dúvidas Frequentes</h2>
            
            <div class="space-y-6">
                <div class="border border-slate-100 rounded-[2rem] overflow-hidden shadow-sm hover:shadow-md transition">
                    <button class="w-full p-8 text-left font-black text-2xl flex justify-between items-center bg-slate-50 transition"
                            @click="activeFaq = (activeFaq === 1 ? null : 1)">
                        Quanto tempo demora a validação?
                        <svg class="w-6 h-6 transition-transform duration-300" :class="activeFaq === 1 ? 'rotate-180' : ''" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M19 9l-7 7-7-7" stroke-width="3"/></svg>
                    </button>
                    <div x-show="activeFaq === 1" x-cloak x-collapse class="p-8 text-slate-500 font-medium text-lg leading-relaxed bg-white border-t border-slate-50">
                        O tempo médio de processamento é de 30 a 90 minutos. Tudo depende da rapidez com que anexa o talão bancário e do tempo de resposta do banco de origem.
                    </div>
                </div>

                <div class="border border-slate-100 rounded-[2rem] overflow-hidden shadow-sm hover:shadow-md transition">
                    <button class="w-full p-8 text-left font-black text-2xl flex justify-between items-center bg-slate-50 transition"
                            @click="activeFaq = (activeFaq === 2 ? null : 2)">
                        É obrigatório anexar o talão?
                        <svg class="w-6 h-6 transition-transform duration-300" :class="activeFaq === 2 ? 'rotate-180' : ''" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M19 9l-7 7-7-7" stroke-width="3"/></svg>
                    </button>
                    <div x-show="activeFaq === 2" x-cloak x-collapse class="p-8 text-slate-500 font-medium text-lg leading-relaxed bg-white border-t border-slate-50">
                        Sim. Para garantir a segurança de ambas as partes, a KwanzaSafe exige o upload do comprovativo da transferência para iniciar o processo de auditoria e libertação dos fundos.
                    </div>
                </div>

                <div class="border border-slate-100 rounded-[2rem] overflow-hidden shadow-sm hover:shadow-md transition">
                    <button class="w-full p-8 text-left font-black text-2xl flex justify-between items-center bg-slate-50 transition"
                            @click="activeFaq = (activeFaq === 3 ? null : 3)">
                        Como recebo o dinheiro?
                        <svg class="w-6 h-6 transition-transform duration-300" :class="activeFaq === 3 ? 'rotate-180' : ''" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M19 9l-7 7-7-7" stroke-width="3"/></svg>
                    </button>
                    <div x-show="activeFaq === 3" x-cloak x-collapse class="p-8 text-slate-500 font-medium text-lg leading-relaxed bg-white border-t border-slate-50">
                        O dinheiro é creditado automaticamente na sua carteira digital KwanzaSafe. A partir daí, pode solicitar o levantamento para qualquer conta bancária em Angola.
                    </div>
                </div>
            </div>
        </div>
    </section>

    <footer class="bg-slate-50 pt-32 pb-16 px-6 border-t border-slate-100 relative overflow-hidden">
        <div class="absolute -right-40 bottom-0 text-[20rem] font-black text-slate-100 select-none">SAFE</div>

        <div class="max-w-7xl mx-auto relative z-10">
            <div class="grid md:grid-cols-2 lg:grid-cols-4 gap-20 mb-32">
                <div class="lg:col-span-2 space-y-10">
                    <img src="{{ asset('assets/images/logos/logo2.PNG') }}" class="h-24 w-auto" alt="Logo Footer">
                    <p class="text-slate-500 font-medium text-xl leading-relaxed max-w-sm italic">
                        "Transformando divisas em progresso com segurança angolana."
                    </p>
                    <div class="flex gap-4">
                        <div class="w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-sm text-slate-400 hover:text-ks-emerald transition cursor-pointer">FB</div>
                        <div class="w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-sm text-slate-400 hover:text-ks-emerald transition cursor-pointer">IG</div>
                        <div class="w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-sm text-slate-400 hover:text-ks-emerald transition cursor-pointer">WA</div>
                    </div>
                </div>
                
                <div class="space-y-10">
                    <h4 class="text-xs font-black text-slate-400 uppercase tracking-[0.3em] italic">Links Rápidos</h4>
                    <ul class="space-y-6 text-sm font-bold text-slate-600">
                        <li><a href="#como-funciona" class="hover:text-ks-emerald transition">Como Funciona</a></li>
                        <li><a href="#depoimentos" class="hover:text-ks-emerald transition">Depoimentos</a></li>
                        <li><a href="#faq" class="hover:text-ks-emerald transition">Dúvidas Frequentes</a></li>
                        <li><a href="https://wa.me/244931719207" class="text-green-600 font-black">WhatsApp Direto</a></li>
                    </ul>
                </div>

                <div class="space-y-10">
                    <h4 class="text-xs font-black text-slate-400 uppercase tracking-[0.3em] italic">Legal & Sede</h4>
                    <ul class="space-y-6 text-sm font-bold text-slate-600">
                        <li><a href="{{ route('terms') }}" class="hover:text-ks-emerald transition">Termos de Uso</a></li>
                        <li><a href="{{ route('privacy') }}" class="hover:text-ks-emerald transition">Privacidade</a></li>
                        <li class="text-slate-400 mt-8">Bairro São Pedro,<br>Huambo, Angola</li>
                    </ul>
                </div>
            </div>

            <div class="border-t border-slate-200 pt-16 flex flex-col md:flex-row justify-between items-center gap-8">
                <div class="text-[10px] font-black text-slate-300 uppercase tracking-[0.5em]">KWANZASAFE © 2026 — TODOS OS DIREITOS RESERVADOS</div>
                <div class="flex items-center gap-2">
                    <div class="w-3 h-3 bg-green-500 rounded-full"></div>
                    <span class="text-[10px] font-black text-slate-400 uppercase tracking-widest">Servidor Local Huambo</span>
                </div>
            </div>
        </div>
    </footer>

    <a href="https://wa.me/244931719207" target="_blank" 
       class="fixed bottom-12 right-12 z-[2000] bg-green-500 text-white p-6 rounded-full shadow-[0_30px_60px_-12px_rgba(34,197,94,0.5)] hover:scale-110 transition duration-300 group">
        <svg class="w-10 h-10 fill-current" viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
        <div class="absolute right-full mr-6 bg-white text-slate-800 px-6 py-3 rounded-2xl font-black text-sm whitespace-nowrap shadow-2xl opacity-0 group-hover:opacity-100 transition pointer-events-none">Suporte KwanzaSafe</div>
    </a>

</body>
</html>