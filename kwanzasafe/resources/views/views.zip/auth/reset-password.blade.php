<!DOCTYPE html>
<html lang="pt-AO">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Recuperar Conta | KwanzaSafe — Tecnologia que Transforma</title>
    
    <meta name="robots" content="noindex, nofollow">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    
    <script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>
    @vite(['resources/css/app.css', 'resources/js/app.js'])

    <style>
        [x-cloak] { display: none !important; }
        body { font-family: 'Inter', sans-serif; overflow-x: hidden; }
        .bg-ks-emerald { background-color: #064e3b; }
        .text-ks-emerald { color: #064e3b; }
        
        .min-h-screen-fix { min-height: 100vh; min-height: -webkit-fill-available; }

        .ks-input {
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            border: 2px solid #f1f5f9;
            background-color: #f8fafc;
        }
        .ks-input:focus {
            border-color: #064e3b;
            box-shadow: 0 0 0 4px rgba(6, 78, 59, 0.08);
            outline: none;
            background-color: white;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade { animation: fadeIn 0.6s ease-out forwards; }
    </style>
</head>
<body class="bg-white min-h-screen-fix flex flex-col lg:flex-row">

    <div class="hidden lg:flex lg:w-1/2 bg-ks-emerald relative overflow-hidden items-center justify-center p-24">
        <div class="absolute inset-0 bg-emerald-500/5 -skew-y-12 translate-y-1/4"></div>
        
        <div class="relative z-10 w-full max-w-xl text-center lg:text-left">
            <div class="mb-16">
                <img src="{{ asset('assets/images/logos/logo2.PNG') }}" alt="KwanzaSafe" class="h-28 w-auto mb-10 mx-auto lg:mx-0">
                <h2 class="text-6xl font-black text-white leading-none tracking-tighter italic">
                    Recupere o seu <br><span class="text-emerald-400">Acesso</span> <br>com Segurança.
                </h2>
                <p class="mt-8 text-emerald-100/60 text-lg font-medium leading-relaxed">Protegemos os seus dados com protocolos bancários. A sua tranquilidade é a nossa prioridade.</p>
            </div>
            
            <div class="relative">
                <img src="{{ asset('assets/images/banners/dashboard-user.jpeg') }}" 
                     alt="KwanzaSafe Dashboard" 
                     class="relative rounded-[3rem] shadow-2xl border-4 border-white/10 transform -rotate-1">
            </div>
        </div>
    </div>

    <div class="flex-1 flex flex-col bg-white">
        
        <header class="h-24 px-8 flex justify-between items-center border-b border-slate-50">
            <a href="/">
                <img src="{{ asset('assets/images/logos/logo.png') }}" class="h-10 w-auto block sm:hidden">
                <img src="{{ asset('assets/images/logos/logo1.png') }}" class="h-12 w-auto hidden sm:block md:hidden">
                <img src="{{ asset('assets/images/logos/logo2.PNG') }}" class="h-14 w-auto hidden md:block lg:hidden">
            </a>
            <a href="{{ route('login') }}" class="text-xs font-black text-ks-emerald uppercase tracking-widest flex items-center gap-2 px-6 py-3 border-2 border-ks-emerald/10 rounded-2xl hover:bg-ks-emerald hover:text-white transition">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M15 19l-7-7 7-7" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>
                Voltar ao Login
            </a>
        </header>

        <div class="flex-1 flex items-center justify-center p-8 sm:p-12 lg:p-24">
            <div class="w-full max-w-md animate-fade">
                
                <div class="mb-12 text-center lg:text-left">
                    <h1 class="text-4xl font-black text-slate-900 tracking-tighter mb-4 italic">Esqueceu a senha?</h1>
                    <p class="text-slate-500 font-medium leading-relaxed">
                        Introduza o seu e-mail abaixo e enviaremos um link seguro para definir uma nova palavra-passe.
                    </p>
                </div>

                @if (session('status'))
                    <div class="mb-8 p-6 bg-emerald-50 border-l-4 border-ks-emerald rounded-2xl text-sm text-ks-emerald font-bold animate-pulse">
                        {{ session('status') }}
                    </div>
                @endif

                @if ($errors->any())
                    <div class="mb-8 p-5 bg-red-50 border-l-4 border-red-500 rounded-2xl">
                        <ul class="text-xs text-red-700 font-black uppercase tracking-widest space-y-1">
                            @foreach ($errors->all() as $error)
                                <li>• {{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif

                <form method="POST" action="{{ route('password.email') }}" class="space-y-8">
                    @csrf

                    <div class="space-y-2">
                        <label for="email" class="block text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] ml-1">E-mail Institucional Verificado</label>
                        <div class="relative">
                            <div class="absolute left-5 top-1/2 -translate-y-1/2 text-slate-300">
                                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                            </div>
                            <input id="email" type="email" name="email" value="{{ old('email') }}" required autofocus 
                                   class="w-full ks-input rounded-[1.5rem] py-6 pl-16 pr-6 text-slate-900 font-bold placeholder:text-slate-300" 
                                   placeholder="nome@exemplo.com">
                        </div>
                    </div>

                    <button type="submit" class="w-full bg-ks-emerald text-white py-6 rounded-[1.5rem] font-black text-sm uppercase tracking-[0.2em] shadow-2xl shadow-emerald-900/20 hover:bg-emerald-900 transition transform active:scale-[0.98] flex items-center justify-center gap-3">
                        ENVIAR LINK DE RECUPERAÇÃO
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M12 19l7-7-7-7M5 12h14" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    </button>
                </form>

                <div class="mt-16 text-center">
                    <p class="text-[10px] font-black text-slate-300 uppercase tracking-[0.4em] italic">Huambo • Tecnologia que Transforma • 2026</p>
                </div>
            </div>
        </div>

        <footer class="p-8 text-center bg-slate-50/50 lg:hidden">
            <p class="text-[10px] font-black text-slate-400 uppercase tracking-[0.4em]">KWANZASAFE © 2026</p>
        </footer>
    </div>

</body>
</html>