<!DOCTYPE html>
<html lang="pt-AO">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Registo | KwanzaSafe — Tecnologia que Transforma</title>
    
    <meta name="robots" content="noindex, nofollow">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    
    <script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>
    @vite(['resources/css/app.css', 'resources/js/app.js'])

    <style>
        [x-cloak] { display: none !important; }
        body { font-family: 'Inter', sans-serif; overflow-x: hidden; }
        .bg-ks-emerald { background-color: #064e3b; }
        .text-ks-emerald { color: #064e3b; }
        
        /* Ajuste de 100vh real */
        .min-h-screen-fix { min-height: 100vh; min-height: -webkit-fill-available; }

        .ks-input {
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            border: 2px solid #f1f5f9;
            background-color: #f8fafc;
        }
        .ks-input:focus {
            border-color: #064e3b;
            box-shadow: 0 0 0 4px rgba(6, 78, 59, 0.1);
            outline: none;
            background-color: white;
        }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .animate-up { animation: fadeInUp 0.7s ease-out forwards; }
    </style>
</head>
<body class="bg-white min-h-screen-fix flex flex-col lg:flex-row">

    <div class="hidden lg:flex lg:w-1/2 bg-ks-emerald relative overflow-hidden items-center justify-center p-24">
        <div class="absolute inset-0 bg-emerald-500/5 -skew-y-12 translate-y-1/4"></div>
        
        <div class="relative z-10 w-full max-w-xl">
            <div class="mb-16">
                <img src="{{ asset('assets/images/logos/logo2.PNG') }}" alt="KwanzaSafe" class="h-28 w-auto mb-10">
                <h2 class="text-6xl font-black text-white leading-[0.95] tracking-tighter italic">
                    A sua <br><span class="text-emerald-400 underline decoration-white/20">Liberdade</span> <br>Financeira.
                </h2>
                <p class="mt-8 text-emerald-100/60 text-lg font-medium leading-relaxed">Abra a sua conta institucional e junte-se à maior rede de câmbio digital de Huambo.</p>
            </div>
            
            <div class="relative group">
                <div class="absolute -inset-6 bg-black/20 rounded-[4rem] blur-3xl opacity-20"></div>
                <img src="{{ asset('assets/images/banners/dashboard-user.jpeg') }}" 
                     alt="KwanzaSafe Interface" 
                     class="relative rounded-[3rem] shadow-2xl border-4 border-white/10 transition duration-700">
            </div>
        </div>
    </div>

    <div class="flex-1 flex flex-col bg-white">
        
        <header class="h-24 px-8 flex justify-between items-center border-b border-slate-50">
            <a href="/">
                <img src="{{ asset('assets/images/logos/logo.png') }}" class="h-10 w-auto block sm:hidden">
                <img src="{{ asset('assets/images/logos/logo1.png') }}" class="h-12 w-auto hidden sm:block md:hidden">
                <img src="{{ asset('assets/images/logos/logo2.PNG') }}" class="h-14 w-auto hidden md:block lg:hidden">
            </a>
            <a href="{{ route('login') }}" class="text-xs font-black text-ks-emerald uppercase tracking-widest px-6 py-3 border-2 border-ks-emerald/10 rounded-2xl hover:bg-ks-emerald hover:text-white transition">
                Fazer Login
            </a>
        </header>

        <div class="flex-1 flex items-center justify-center p-8 sm:p-12 lg:p-24">
            <div class="w-full max-w-md animate-up">
                
                <div class="mb-12">
                    <h1 class="text-4xl font-black text-slate-900 tracking-tighter mb-4 italic">Registo de Membro</h1>
                    <p class="text-slate-500 font-medium">Preencha os campos abaixo com rigor.</p>
                </div>

                @if ($errors->any())
                    <div class="mb-8 p-5 bg-red-50 border-l-4 border-red-500 rounded-2xl">
                        <ul class="text-xs text-red-700 font-black uppercase tracking-widest space-y-1">
                            @foreach ($errors->all() as $error)
                                <li>• {{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif

                <form method="POST" action="{{ route('register') }}" class="space-y-6">
                    @csrf

                    <div class="space-y-2">
                        <label for="full_name" class="block text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] ml-1">Nome Completo</label>
                        <div class="relative">
                            <div class="absolute left-5 top-1/2 -translate-y-1/2 text-slate-300">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                            </div>
                            <input id="full_name" 
                                type="text" 
                                name="full_name" 
                                value="{{ old('full_name') }}" 
                                required 
                                autofocus 
                                autocomplete="name"
                                class="w-full ks-input rounded-[1.5rem] py-5 pl-14 pr-6 text-slate-900 font-bold placeholder:text-slate-300" 
                                placeholder="Introduza o seu nome completo">
                        </div>
                    </div>

                    <div class="space-y-2">
                        <label for="email" class="block text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] ml-1">E-mail Institucional</label>
                        <div class="relative">
                            <div class="absolute left-5 top-1/2 -translate-y-1/2 text-slate-300">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M16 12a4 4 0 10-8 0 4 4 0 008 0zm0 0v1.5a2.5 2.5 0 005 0V12a9 9 0 10-9 9m4.5-1.206a8.959 8.959 0 01-4.5 1.207" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                            </div>
                            <input id="email" type="email" name="email" value="{{ old('email') }}" required autocomplete="email"
                                   class="w-full ks-input rounded-[1.5rem] py-5 pl-14 pr-6 text-slate-900 font-bold placeholder:text-slate-300" 
                                   placeholder="nome@email.com">
                        </div>
                    </div>

                    <div class="space-y-2">
                        <label for="password" class="block text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] ml-1">Palavra-Passe (Máx 12)</label>
                        <div class="relative" x-data="{ show: false }">
                            <div class="absolute left-5 top-1/2 -translate-y-1/2 text-slate-300">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                            </div>
                            <input id="password" :type="show ? 'text' : 'password'" name="password" required maxlength="12" autocomplete="new-password"
                                   class="w-full ks-input rounded-[1.5rem] py-5 pl-14 pr-14 text-slate-900 font-bold placeholder:text-slate-300" 
                                   placeholder="••••••••••••">
                            <button type="button" @click="show = !show" class="absolute right-5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-ks-emerald transition">
                                <svg x-show="!show" class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" stroke-width="2"/><path d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" stroke-width="2"/></svg>
                                <svg x-show="show" class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.542-7a9.97 9.97 0 011.563-3.076m10.89 3.576L15 12a3 3 0 11-5.714-1.225m5.714 1.225l1.42 1.42M9 9l1.42 1.42M3 3l18 18" stroke-width="2"/></svg>
                            </button>
                        </div>
                    </div>

                    <div class="space-y-2">
                        <label for="password_confirmation" class="block text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] ml-1">Confirmar Senha</label>
                        <input id="password_confirmation" type="password" name="password_confirmation" required maxlength="12" autocomplete="new-password"
                               class="w-full ks-input rounded-[1.5rem] py-5 px-6 text-slate-900 font-bold placeholder:text-slate-300" 
                               placeholder="••••••••••••">
                    </div>

                    <button type="submit" class="w-full bg-ks-emerald text-white py-6 rounded-[1.5rem] font-black text-sm uppercase tracking-[0.2em] shadow-2xl shadow-emerald-900/20 hover:bg-emerald-900 transition transform active:scale-[0.98] flex items-center justify-center gap-3">
                        FINALIZAR REGISTO
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    </button>
                </form>

                <div class="mt-12 text-center">
                    <p class="text-[10px] font-black text-slate-300 uppercase tracking-[0.4em] mb-4 italic">Huambo • Angola • 2026</p>
                </div>
            </div>
        </div>
    </div>

</body>
</html>