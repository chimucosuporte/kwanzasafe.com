<!DOCTYPE html>
<html lang="pt-AO">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Entrar | KwanzaSafe — Tecnologia que Transforma</title>
    
    <meta name="robots" content="noindex, nofollow">
    <meta name="author" content="Edson Chimuco">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    
    <script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>
    
    @vite(['resources/css/app.css', 'resources/js/app.js'])

    <style>
        [x-cloak] { display: none !important; }
        body { font-family: 'Inter', sans-serif; overflow-x: hidden; }
        
        .bg-ks-emerald { background-color: #064e3b; }
        .text-ks-emerald { color: #064e3b; }
        
        /* Ajuste de 100vh real para mobile */
        .min-h-screen-fix { min-height: 100vh; min-height: -webkit-fill-available; }

        /* Input Estilizado Premium */
        .ks-input {
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            border: 2px solid #f1f5f9;
        }
        .ks-input:focus {
            border-color: #064e3b;
            box-shadow: 0 0 0 4px rgba(6, 78, 59, 0.08);
            outline: none;
            background: white;
        }

        /* Animação Lateral */
        @keyframes fadeInRight {
            from { opacity: 0; transform: translateX(30px); }
            to { opacity: 1; transform: translateX(0); }
        }
        .animate-fade-in { animation: fadeInRight 0.8s ease-out forwards; }
    </style>
</head>
<body class="bg-white min-h-screen-fix flex flex-col lg:flex-row">

    <div class="hidden lg:flex lg:w-1/2 bg-ks-emerald relative overflow-hidden items-center justify-center p-20">
        <div class="absolute top-0 right-0 w-full h-full bg-emerald-500/10 -skew-x-12 translate-x-1/3"></div>
        <div class="absolute -bottom-20 -left-20 w-80 h-80 bg-white/5 rounded-full blur-[100px]"></div>

        <div class="relative z-10 w-full max-w-2xl">
            <div class="mb-12">
                <img src="{{ asset('assets/images/logos/logo2.PNG') }}" alt="KwanzaSafe" class="h-32 w-auto mb-8">
                <h2 class="text-5xl font-black text-white leading-tight tracking-tighter italic">
                    Segurança que <br>acompanha o seu <br><span class="text-emerald-400">Progresso.</span>
                </h2>
            </div>
            
            <div class="relative">
                <div class="absolute -inset-4 bg-white/5 rounded-[3rem] rotate-3"></div>
                <img src="{{ asset('assets/images/banners/dashboard-user.jpeg') }}" 
                     alt="Interface KwanzaSafe" 
                     class="relative rounded-[2.5rem] shadow-2xl border-4 border-white/10 transform -rotate-2 hover:rotate-0 transition duration-700">
            </div>
        </div>
    </div>

    <div class="flex-1 flex flex-col bg-white">
        
        <header class="h-24 px-8 flex justify-between items-center border-b border-slate-50">
            <a href="/">
                <img src="{{ asset('assets/images/logos/logo.png') }}" class="h-10 w-auto block sm:hidden">
                <img src="{{ asset('assets/images/logos/logo1.png') }}" class="h-12 w-auto hidden sm:block md:hidden">
                <img src="{{ asset('assets/images/logos/logo2.PNG') }}" class="h-14 w-auto hidden md:block lg:hidden">
            </a>
            <a href="/" class="text-sm font-bold text-slate-400 hover:text-ks-emerald transition flex items-center gap-2">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M10 19l-7-7m0 0l7-7m-7 7h18" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
                <span class="hidden sm:inline">Voltar ao Início</span>
            </a>
        </header>

        <div class="flex-1 flex items-center justify-center p-8 sm:p-12 lg:p-20">
            <div class="w-full max-w-md animate-fade-in">
                
                <div class="mb-12">
                    <h1 class="text-4xl font-black text-slate-900 tracking-tighter mb-2 italic">Bem-vindo de volta</h1>
                    <p class="text-slate-500 font-medium">Introduza os seus dados para aceder à sua carteira.</p>
                </div>

                @if ($errors->any())
                    <div class="mb-8 p-4 bg-red-50 border-l-4 border-red-500 rounded-2xl text-sm text-red-700 font-bold">
                        As credenciais introduzidas não são válidas.
                    </div>
                @endif

                <form method="POST" action="{{ route('login') }}" class="space-y-7">
                    @csrf

                    <div class="space-y-2">
                        <label for="email" class="block text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] ml-1">E-mail Institucional</label>
                        <div class="relative">
                            <span class="absolute left-5 top-1/2 -translate-y-1/2 text-slate-300">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M16 12a4 4 0 10-8 0 4 4 0 008 0zm0 0v1.5a2.5 2.5 0 005 0V12a9 9 0 10-9 9m4.5-1.206a8.959 8.959 0 01-4.5 1.207" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                            </span>
                            <input id="email" type="email" name="email" value="{{ old('email') }}" required autofocus 
                                   class="w-full ks-input bg-slate-50 rounded-[1.5rem] py-5 pl-14 pr-6 text-slate-900 font-bold placeholder:text-slate-300" 
                                   placeholder="nome@exemplo.com">
                        </div>
                    </div>

                    <div class="space-y-2">
                        <div class="flex justify-between items-center ml-1">
                            <label for="password" class="block text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">Palavra-Passe</label>
                            <a href="{{ route('password.request') }}" class="text-[10px] font-black text-ks-emerald uppercase hover:underline">Esqueci-me</a>
                        </div>
                        <div class="relative" x-data="{ show: false }">
                            <span class="absolute left-5 top-1/2 -translate-y-1/2 text-slate-300">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                            </span>
                            <input id="password" :type="show ? 'text' : 'password'" name="password" required 
                                   maxlength="12"
                                   class="w-full ks-input bg-slate-50 rounded-[1.5rem] py-5 pl-14 pr-14 text-slate-900 font-bold placeholder:text-slate-300" 
                                   placeholder="••••••••••••">
                            <button type="button" @click="show = !show" class="absolute right-5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-ks-emerald transition">
                                <svg x-show="!show" class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" stroke-width="2"/><path d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" stroke-width="2"/></svg>
                                <svg x-show="show" class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.542-7a9.97 9.97 0 011.563-3.076m10.89 3.576L15 12a3 3 0 11-5.714-1.225m5.714 1.225l1.42 1.42M9 9l1.42 1.42M3 3l18 18" stroke-width="2"/></svg>
                            </button>
                        </div>
                        <p class="text-[9px] text-slate-400 mt-2 ml-1 font-bold uppercase tracking-wider italic">* Limite máximo de 12 caracteres.</p>
                    </div>

                    <div class="flex items-center px-1">
                        <input id="remember_me" type="checkbox" name="remember" class="w-5 h-5 text-ks-emerald border-slate-200 rounded-lg focus:ring-ks-emerald">
                        <label for="remember_me" class="ml-3 text-sm font-bold text-slate-500">Manter sessão ativa</label>
                    </div>

                    <button type="submit" class="w-full bg-ks-emerald text-white py-6 rounded-[1.5rem] font-black text-sm uppercase tracking-[0.2em] shadow-2xl shadow-emerald-900/20 hover:bg-emerald-900 transition transform active:scale-[0.98] flex items-center justify-center gap-3">
                        ENTRAR NO SISTEMA
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M14 5l7 7m0 0l-7 7m7-7H3" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    </button>
                </form>

                <div class="mt-12 text-center">
                    <p class="text-sm font-bold text-slate-400 mb-2">Ainda não faz parte da elite?</p>
                    <a href="{{ route('register') }}" class="text-sm font-black text-ks-emerald uppercase tracking-widest border-b-2 border-emerald-100 hover:border-ks-emerald transition pb-1">Criar Conta Gratuita</a>
                </div>
            </div>
        </div>

        <footer class="p-8 text-center bg-slate-50/50 lg:hidden">
            <p class="text-[10px] font-black text-slate-300 uppercase tracking-[0.4em]">KWANZASAFE © 2026 — TECNOLOGIA QUE TRANSFORMA</p>
        </footer>
    </div>

</body>
</html>